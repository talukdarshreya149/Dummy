package com.cg.AmazonTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class AmazonTest {

public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe");
		WebDriver driver= new ChromeDriver();	
		driver.manage().window().maximize();
		driver.get("http://www.amazon.com");
		WebElement element=driver.findElement(By.name("field-keywords"));
		element.sendKeys("watches");
		element.submit();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		System.out.println("Page title is: " + driver.getTitle());
		driver.quit();
		
	}
}
