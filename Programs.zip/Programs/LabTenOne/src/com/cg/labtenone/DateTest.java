package com.cg.labtenone;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class DateTest {

	public static Date date;
	
	@BeforeClass
	public static void testinitializer(){
		date=new Date(25,12,2010);
	}

	@Test
	public void testday() {
		date.setDay(12);
		assertEquals(12, date.getMonth());
		}
@Test
public void testYear() {
	date.setDay(2010);
	assertEquals(2010, date.getYear());
}

}
