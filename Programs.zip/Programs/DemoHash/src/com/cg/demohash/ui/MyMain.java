package com.cg.demohash.ui;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MyMain {
	public static void main(String[] args)
	{
		Map<Integer,String > mymap=new HashMap<>();
		mymap.put(1," Abcd");
		mymap.put(2,"Bcd");
		mymap.put(3,"Cde");
		System.out.println(mymap);
		System.out.println(mymap.keySet()); // allkeys
		System.out.println(mymap.get(2));// 2 key...
		System.out.println(mymap.values());// all values
		
		for(Integer keys:mymap.keySet())
		{
			System.out.println(" Key is "+ keys  +  " Value is " +  mymap.get(keys));
		
		}
		
		System.out.println("-------Iterator-----");
		Set mydata=mymap.entrySet(); // keyset and entryset
		Iterator it=mydata.iterator();
		while(it.hasNext() )
		{
			System.out.println(it.next());
		}
	}

}
