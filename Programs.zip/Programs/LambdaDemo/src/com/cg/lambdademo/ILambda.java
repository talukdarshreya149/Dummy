package com.cg.lambdademo;

public interface ILambda {

	default int add(int a,int b) //this is applicable for existing project to enhance or change
	{
	return (a+ b);
	
}
	

}
