package com.cg.demonine.ui;

public class DemoArray {
	public static void main(String...args)
	{
		showData(10,30);
	}
	
		
	public static void	showData(int ...num)
	{
		for(int i:num)
		System.out.println(i);
	}
		}

