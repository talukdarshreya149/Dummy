package com.cg.student.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashSet;

import com.cg.student.dao.IStudentDao;
import com.cg.student.dao.StudentDaoImpl;
import com.cg.student.dto.StudentDto;
import com.cg.student.exception.IMyExceptionMessages;
import com.cg.student.exception.MyException;

public class StudentServiceImpl implements IStudentService {

	 private IStudentDao dao=null;
	 
	 public StudentServiceImpl (){
		 
		dao= new StudentDaoImpl();
	 }
		@Override
	public int addStudent(StudentDto studentdto) {
		// TODO Auto-generated method stub
			
		return dao.addStudentDao(studentdto);
	}
	@Override
	public HashSet<StudentDto> viewStudentDetails() {
		// TODO Auto-generated method stub
	return dao.viewStudentDetails()	;
	}
	@Override
	public StudentDto searchStudent(int id) {
		// TODO Auto-generated method stub
		return dao.searchStudent(id);
	}
	@Override
	public void deleteStudent(int did) {
		// TODO Auto-generated method stub
	dao.deleteStudent(did);	
	}
	@Override
	public boolean validate(String name, String dob) throws MyException {
		// TODO Auto-generated method stub
		boolean result=false;
		if(name.trim().matches("^[a-zA-Z]+$")) {
			
			try {
			DateTimeFormatter formatter= DateTimeFormatter.ofPattern("MM-dd-yyyy");
			LocalDate.parse(dob,formatter);
			result=true;
			} catch(DateTimeParseException e) {
				throw new MyException(IMyExceptionMessages.ERROR2);
			}
			
		}else
		{
			throw new MyException(IMyExceptionMessages.ERROR2);
		}
		
		return result;
	}
	
}