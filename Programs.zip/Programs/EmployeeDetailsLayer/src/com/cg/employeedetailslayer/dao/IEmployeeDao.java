package com.cg.employeedetailslayer.dao;

import java.util.ArrayList;

import com.cg.employeedetailslayer.dto.Employee;

public interface IEmployeeDao {
public ArrayList<Employee>getEmployeeDetails();
public Employee getDetails(int empId);
public void  addEmployeeDaoImpl(Employee em);
public void updatesalary(int id1,double sal1);
}
