package com.cg.thread;

public class MyThread extends Thread {
	
private Display disp;
private String name;
public MyThread(Display disp,String name) {
	this.disp=disp;
	this.name=name;
}
public void run() {
	
disp.wish(name);
}
}