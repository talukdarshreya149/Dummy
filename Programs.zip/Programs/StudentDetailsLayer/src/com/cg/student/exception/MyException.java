package com.cg.student.exception;

public class MyException extends Exception {
	
public MyException() {
	System.out.println("Invalid details");
}

public MyException(String message) {
	super(message);
}
}
