package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.service.Employee_Insurance;
import com.cg.eis.service.Service;

public class MainMedical {
	public static void main(String [] args)
	{
		
		String des=new String();
		Service emp= new Service();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Employee Id ");
		int empId=sc.nextInt();
		System.out.println("Enter Employee Name ");
		String empName=sc.next();
		
		
		System.out.println("Enter Employee Salary ");
		double empSal= sc.nextDouble();
		System.out.println("Enter Employee Designation ");
		 des=sc.next();
	
	
	String scheme=new String();
	String sch =emp.checkScheme(des,empSal);
		
	System.out.println("*****EMPLOYEE DETAILS******  " );
		
	System.out.println("Employee Id" + empId);
		System.out.println("Employee Name" + empName);
		
		System.out.println("Employee Salary" + empSal);
		
		System.out.println("Employee Designation" + des);
				
		System.out.println("Employee Scheme" + sch);
		
	sc.close();
		
	}

}
