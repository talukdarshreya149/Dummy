package com.cg.demo4.ui;

public class forloop 
{
	public static void main(String[] args)
	{
		String ename[] = {"a","b", "c", "d", "e"};
		System.out.println("enhance for loop");
	
	for(String str: ename)
		{
		System.out.println(str);}
		}

}
