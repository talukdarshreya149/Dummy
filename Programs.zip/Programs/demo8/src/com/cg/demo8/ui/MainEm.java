package com.cg.demo8.ui;

public class MainEm {

	public static void main(String [] args) {
		
		Employe em=new Employe();
		try{
			 em.getData(10,0);
			
		}catch(ArithmeticException ex)
		{
			System.out.println(ex.getMessage());
		}
	}
}
