package com.cg.loc1;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Sender {

	public static void mai(String[] args) throws FileNotFoundException, IOException {

		Employee emp = new Employee();
		emp.setEmpId(1001);
		emp.setEmpName("Jane");
		emp.setEmpSalary(12000.00);
		emp.setEmpDesignation("Programmer");
		System.out.println(emp.hashCode());
		
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(new File("D://Users//learning//Desktop//file.text")));
			oos.writeObject(emp);
			System.out.println("Done!!");
			oos.close();
		

	}
}