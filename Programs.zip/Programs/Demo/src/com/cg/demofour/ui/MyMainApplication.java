package com.cg.demofour.ui;
import com.cg.demofour.dto.Employee;

public class MyMainApplication
{

	public static void main(String[] args)

{
		Employee emp= new Employee();
		emp.setEmpId(1001);
		emp.setEmpName("ABCD");
		emp.setEmpSal(9999.1);
		System.out.println(emp);
}
	}

