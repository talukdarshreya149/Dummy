package com.cg.service;

public interface ILoginsService {

public boolean login(String username,String password);

}
