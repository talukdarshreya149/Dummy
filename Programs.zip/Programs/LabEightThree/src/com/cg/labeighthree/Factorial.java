package com.cg.labeighthree;

public class Factorial implements Runnable {
	
int number=(int)(Math.random()*10000);

static Thread thread1=new Thread(new Factorial());
static Thread thread2=new Thread(new Factorial());

public static void main(String[] args) {
	
thread1.start();
thread2.start();
	
}
@Override
public void run() {
	// TODO Auto-generated method stub
	synchronized (thread1) {
		System.out.println("Number is:" + number);
			
	}
	
	synchronized (thread2) {
		int fact=1;
for(int i=1;i<=number;i++) {
fact=fact*i;
}
System.out.println("Factorial is :" + fact);

}
}
}
