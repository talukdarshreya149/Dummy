package com.cg.employee.dao;


import com.cg.employee.dto.Employee;

public interface IEmployeeDao {

public void addDetailsDao(Employee emp) throws Exception;

public Employee getEmployeeDetailsDao(String scheme1) throws Exception;


}