package com.cg.studentadmissionhash.service.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.studentadmissionhash.dao.IStudentColDao;
import com.cg.studentadmissionhash.dao.StudentColDaoImpl;
import com.cg.studentadmissionhash.dto.StudentDto;

public class StudentJunitTest {
IStudentColDao dao=new StudentColDaoImpl();
	@BeforeClass
	public static  void setUp() throws Exception {
		System.out.println("Testing Starts");
	}
@AfterClass
public static void endUp() throws Exception{
	System.out.println("Testing ends");
	
}
	@Test
	public void getCollegeDetailsTest() {
		assertEquals("IIT-B",dao.getCollegeDetails().get("Mumbai"));
		
	}
	
	@Test
	public void addStudentDetails() {
		StudentDto dto=new StudentDto();
		dto.setAge(22);
		dto.setCity("Mumbai");
		dto.setEmail("shreya@gmail.com");
		dto.setGender('F');
		dto.setName("Shreya");
		dto.setPhone("9876543210");
		dao.addStudentDetails(dto);
			
	}
	
	@Test
	public void getStudentDetailsTest() {
		StudentDto student=new StudentDto();
		assertNotSame("shreya",dao.getStudentDetails().get(student.getName()));
	}
	
@Test
public void getCollegeValidTest() {
	assertNull(dao.getCollegeDetails().get(" "));
}
}
