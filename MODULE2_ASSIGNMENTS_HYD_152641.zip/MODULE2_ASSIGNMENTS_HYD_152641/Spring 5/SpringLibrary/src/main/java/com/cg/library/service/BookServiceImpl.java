package com.cg.library.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.library.beans.Book;
import com.cg.library.repo.BookRepository;

@Service
public class BookServiceImpl implements BookService {

	@Autowired
	private BookRepository repo;
	
	@Override
	public List<Book> getAllBooks() {
		List<Book> list=new ArrayList<>();
		repo.findAll().forEach(list::add);
		return list;
	}

	
	@Override
	public void addBook(Book b) {
		repo.save(b);
	}

	@Override
	public void updateBook(Book b, int id) {
		repo.save(b);
	}

	@Override
	public void deleteBook(int id) {
		repo.deleteById(id);
		
	}


	@Override
	public Optional<Book> getBookById(int id) {
		
		return repo.findById(id);
	}

}
