package com.cg.stringoperation.ui;
import java.util.Scanner;
public class UserNameEmployee 
{
public static void main(String [] args)
{
	String str=new String();
	Scanner sc=new Scanner(System.in);
str=sc.next();

if(str.length()>=12)
    {	
	checkUsername(str);

	}
	else
	{
		System.out.println(" Not Valid Username");
	}
	sc.close();
	
}
private static void checkUsername(String str)
{
	if(str.endsWith("_job"))
	{
		System.out.println("Valid username");
	}
}
}
