package com.cg.mra.dao;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.mra.userbean.Account;

//------------------------    <Mobile_Recharge> Application --------------------------
	/*******************************************************************************************************
	 - Method Name	        :	<Testcases>
	 - Input Parameters	:	<variable name(s)> <data type(s)>
	 - Return Type		:	<variable name> <data type>
	 - Throws		:  	<Application_name>Exception
	 - Author		:	<Shreya_Talukdar_152641>
	 - Creation Date	:	11/07/2018
	 - Description		:	All the 3 test cases are executed successfully
	 ********************************************************************************************************/

public class AccountTest {
	private static final double DELTA=1e-15;
	static AccountDao test=null;
	static Account account=null;

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		
		test=new AccountDaoImpl();
		account=new Account();
	
			}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("Test is executed");
	}

@Test
	public void balanceEnquiryTest() throws Exception {
	account.setCustomerName("shreya");
	account.setMobileNo("9876543210");
	
	AccountDaoImpl.hashmap.put(account.getMobileNo(),account);
	assertEquals("shreya",AccountDaoImpl.hashmap.get("9876543210").getCustomerName());
		}

	@Test
	public void rechargeAccountTest() {
		account.setAccountBalance(1000);
	account.setRechargeAmount(200);
		account.setCustomerName("shreya");
		account.setMobileNo("9876543210");
		
		AccountDaoImpl.hashmap.put(account.getMobileNo(),account);
		double finalamount=test.rechargeAccount("9876543210",200);
		assertEquals(1200,finalamount,DELTA);	
	}

}
