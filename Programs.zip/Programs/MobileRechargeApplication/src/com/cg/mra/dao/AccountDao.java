package com.cg.mra.dao;


import com.cg.mra.userbean.Account;

public interface AccountDao {
	
public Account getAccount(String mobileNo);
public int rechargeAccount(String mobileNo, double rechargeAmount) ;
	
}
