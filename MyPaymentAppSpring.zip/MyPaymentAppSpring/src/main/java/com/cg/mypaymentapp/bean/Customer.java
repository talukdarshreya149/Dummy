package com.cg.mypaymentapp.bean;

import java.math.BigDecimal;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;


@Entity


public class Customer {
	
	private String name;
	@Id
	private String mobileNo;
	@Embedded
	private Wallet wallet;
	private String transaction;
	
	public Customer() {
	
		wallet=new Wallet();	
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public BigDecimal getWallet() {
		return wallet.getBalance();
	}
	public void setWallet(BigDecimal amount) {
		wallet.setBalance(amount);
	}

	public Customer(String name, String mobileNo, Wallet wallet, String transaction) {
		super();
		this.name = name;
		this.mobileNo = mobileNo;
		this.wallet = wallet;
		this.transaction = transaction;
	}

	public String getTransaction() {
		return transaction;
	}

	public void setTransaction(String transaction) {
		this.transaction = transaction;
	}

	@Override
	public String toString() {
		return "Customer [name=" + name + ", mobileNo=" + mobileNo + ", wallet=" + wallet + ", transaction="
				+ transaction + "]";
	}
	
	
}
