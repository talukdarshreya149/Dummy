package com.cg.stringoperation.ui;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Scanner;
public class ZonedTime 
{
public static void main(String[] args)
{
		Scanner sc=new Scanner(System.in);
		String zone=sc.next();
	ZonedDateTime zoneIndia = ZonedDateTime.now();
	System.out.println(zoneIndia);
	
	ZonedDateTime z= ZonedDateTime.now(ZoneId.of(zone));

	System.out.println(z);
	sc.close();
}
	
}
