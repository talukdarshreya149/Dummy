package com.cg.demoten.dao;

import java.util.List;

import com.cg.demoten.dto.Product;

public interface IProductDao {
	
	
	
	public void addProductDao(Product pro);
	
	public List<Product>showAllProductDao();
	public Product searchProductDao(int prodid);
	public void removeProductDao(int prorid);
	

}
