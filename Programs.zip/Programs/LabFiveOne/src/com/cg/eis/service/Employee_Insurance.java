package com.cg.eis.service;

public interface Employee_Insurance 
{
public String checkScheme(String empDesign, double empSal);
 
	
}
