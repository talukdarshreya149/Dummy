package com.cg.Test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ImageTest {

	WebDriver driver;

	
	@Before
	public  void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe" );
		  driver=new ChromeDriver();
	}

	@After
	public  void tearDownAfterClass() throws Exception {
		driver.quit();
	}

	@Test
    public void imagetest()
    {
        driver.get("https://www.amazon.com/");
        List<WebElement> listwebelement = driver.findElements(By.tagName("img"));
        int i=0;
        for (WebElement Element : listwebelement) {
            i = i+1;
            System.out.println(Element.getTagName());
            System.out.println(Element.getText());

            String link = Element.getAttribute("alt");

            System.out.println(link);
        }
        System.out.println("total objects founds " + i);
    }

}
