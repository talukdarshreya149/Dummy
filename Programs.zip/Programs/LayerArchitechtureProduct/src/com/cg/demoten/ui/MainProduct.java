package com.cg.demoten.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.demoten.dto.Product;
import com.cg.demoten.service.IProductService;
import com.cg.demoten.service.ProductService;

public class MainProduct {
	public static void main(String [] args)
	{
		IProductService proservice=new ProductService ();
		int choice=0;
	do {
		printDetails();
		System.out.println("Enter your choice");
	Scanner sc=new Scanner(System.in)	;
	choice=sc.nextInt();
	switch(choice)
	{
	
	case 1: //Add
		System.out.println("ENTER PPRODUCT ID");
		int pid=sc.nextInt();
		System.out.println("ENTER PRODUCT NAME");
		String pname=sc.next();
		System.out.println("ENTER PRODUCT PRICE");
		double pprice=sc.nextDouble();
		
		Product prod=new Product();
		prod.setProdId(pid);
		prod.setProdName(pname);
		prod.setProdPrice(pprice);
		
		
	proservice.addProduct(prod);	
		
		
		break;
	case 2: //Show
		List<Product> allData=proservice.showAllProduct();
		for(Product all: allData)
		{
			System.out.println("Product Id " + all.getProdId());
			System.out.println("Product Name " + all.getProdName());
			System.out.println("Product Price " + all.getProdPrice());
		}
	break;
	case 3: // Search
		System.out.println("Enter Product Id");
		int prodId=sc.nextInt();
Product productSearch=proservice.searchProduct(prodId);
	if(productSearch.getProdId()==0) {
		System.out.println("Product Not Found...");	
	}else
	{
		System.out.println("Product Id " + productSearch.getProdId());
		System.out.println("Product Name " + productSearch.getProdName());
		System.out.println("Product Price " + productSearch.getProdPrice());
	}

break;
	case 4: // Remove
		System.out.println("Enter Product Id");
		int rid=sc.nextInt();
	proservice.removeProduct(rid);
		break;
	case 5: //Exit
		System.exit(0);
break;
default: System.out.println("----Wrong Choice----");
	break;
		
	}
	sc.close();
	}
	
	while(choice!=5);
		
	}	
		
		public static  void printDetails()
		
		{
			System.out.println("1. Add Product...");
			System.out.println("2. Show All Product...");
			System.out.println("3. Search Product...");
			System.out.println("4. Remove Product..");
			System.out.println("5. Exit...");
		}
				
		
			
}

	