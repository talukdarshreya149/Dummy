package ui;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import dto.TicketBean;
import dto.TicketCategory;
import service.TicketService;
import service.TicketServiceImpl;

public class MainUI {
	static TicketService service = new TicketServiceImpl();

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		int choice = 0;
		do {
			System.out.println("1. Raise a Ticket\n" + "2. Exit from the system " + "\n" + "Enter Your Choice\n");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				System.out.println("1.software installation");
				System.out.println("2.mailbox creation");
				System.out.println("3.mailbox issues");
				System.out.println("Enter Ticket Category");
				String ticketCategoryId = scanner.next();
				List<TicketCategory> categories = service.listTicketCategory();
				for (TicketCategory ticketCategory : categories) {
					if (ticketCategory.getTicketCategoryId().equals(ticketCategoryId)) {
						System.out.println("Enter Ticket Description");
						String ticketDescription = scanner.next();
						System.out.println("Enter Ticket Priority(1.Low 2.Medium 3.High)");
						String ticketPriority = scanner.next();
						TicketBean bean = new TicketBean();
						bean.setTicketCategoryId(ticketCategoryId);
						bean.setTicketDescription(ticketDescription);
						bean.setTicketPriority(ticketPriority);
						boolean output = service.raiseNewTicket(bean);
						if (output) {
							Date date = new Date();
							SimpleDateFormat sdf = new SimpleDateFormat("dd MMMM yyyy hh:mm a");
							String strDate = sdf.format(date);
							System.out.println(
									"Ticket Number: " + bean.getTicketNo() + " logged successfully at " + strDate);
						}
					}else {
						System.out.println("Enter Valid Chocie");
					}
				}

				break;
			case 2:
				System.exit(0);
				break;

			default:
				break;
			}
		} while (choice != 2);
	}

}
