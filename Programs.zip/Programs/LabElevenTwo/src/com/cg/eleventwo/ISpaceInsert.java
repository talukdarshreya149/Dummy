package com.cg.eleventwo;


@FunctionalInterface
public interface ISpaceInsert {

	String space(String str);
	
}
