package dao;

import java.util.List;

import dto.TicketBean;
import dto.TicketCategory;

public interface TicketDAO {
	public boolean raiseNewTicket(TicketBean ticketBean);
	public List<TicketCategory>listTicketCategory();

}
