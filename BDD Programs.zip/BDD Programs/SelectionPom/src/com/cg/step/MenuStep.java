package com.cg.step;

import static org.junit.Assert.*;

import org.junit.After;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;


import com.cg.pojo.MenuBeans;
import com.cg.util.DriverUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MenuStep {
	private WebDriver driver;
	private MenuBeans menubeans;
	DriverUtil util=new DriverUtil();
	
	
	@Before
	public void initialize() {

		driver=util.initiateDriver("Chrome");
		driver.manage().window().maximize();	
		menubeans=new MenuBeans();
		PageFactory.initElements(driver, menubeans);
	}
@Test
public void test() throws Throwable
{
	enter_username();
	choose_Designation();
	select_from_country();
	click_on_select();
	reset();
	go_to_Next_page();
}
	
@Given("^Enter username$")
public void enter_username() throws Throwable {
   driver.get("http://localhost:9091/SelectionPom/index.html ");
}

@When("^Choose Designation$")
public void choose_Designation() throws Throwable {
   menubeans.setUsername("shreya");
   menubeans.setDesignation("design1");
   menubeans.setCountry("India");
   Thread.sleep(3000);
}

@Then("^Select from country$")
public void select_from_country() throws Throwable {
    
}

@Then("^Click on select$")
public void click_on_select() throws Throwable {
    
}

@Then("^Reset$")
public void reset() throws Throwable {
   menubeans.clickReset();
}

@Then("^Go to Next page$")
public void go_to_Next_page() throws Throwable {
   menubeans.clickNext();
}


@After
public void tearDown() throws Exception {
	Thread.sleep(3000);
	driver.quit();
}

}
