package com.cg.demoone.ui;

public class Calculator 
{
	public int addNumber(int numOne, int numTwo)
	{ return numOne+numTwo;
	
	}
	public int subNumber(int numOne, int numTwo)
	{ return numOne-numTwo;
	
	}
	public int mulNumber(int numOne, int numTwo)
	{ return numOne*numTwo;
	
	}
	public int divNumber(int numOne, int numTwo)
	{ return numOne/numTwo;
	
	}
}
