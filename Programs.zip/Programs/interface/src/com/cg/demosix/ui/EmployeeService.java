package com.cg.demosix.ui;

import com.cg.demosix.service.iEmployeeService;

public class EmployeeService implements iEmployeeService {

	@Override
	public void getData() {
		// TODO Auto-generated method stub
		System.out.println("in get Data...");
	}

	@Override
	public double showData() {
		// TODO Auto-generated method stub
		return 2.0;
	}

}
