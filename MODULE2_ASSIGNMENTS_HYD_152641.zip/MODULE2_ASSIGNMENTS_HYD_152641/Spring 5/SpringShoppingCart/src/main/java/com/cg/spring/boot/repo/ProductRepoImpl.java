package com.cg.spring.boot.repo;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.spring.boot.dto.Product;

@Repository("productrepo")
public class ProductRepoImpl implements ProductRepo{
 
	private static List<Product> productDetails=null;
	
  static
	{
		productDetails= new ArrayList<>();

		Product p1=new Product();
		p1.setProdid("7S");
		p1.setProdname("IPhone7");
		p1.setProdmodel("IP10544");
		p1.setProdprice(30000);
		productDetails.add(p1);
		
		Product p2=new Product();
		p2.setProdid("S8");
		p2.setProdname("Samsung");
        p2.setProdmodel("GS3330");
        p2.setProdprice(25000);
        productDetails.add(p2);
        
        Product p3=new Product();
		p3.setProdid("A1");
		p3.setProdname("MI");
        p3.setProdmodel("TW11330");
        p3.setProdprice(20000);
        productDetails.add(p3);
       
        Product p4=new Product();
		p4.setProdid("Note 5");
		p4.setProdname("Redmi Note5 Pro");
        p4.setProdmodel("STHJ330");
        p4.setProdprice(15000);
        productDetails.add(p4);
	}
	
	@Override
	public List<Product> getAllProducts() {
		
		return productDetails;
	}

	@Override
	public Product getProductById(String id) {
		
		for(Product product: productDetails)
		{
			if(product.getProdid().equals(id)) 
			
		return product;
		
	}
		return null;
	}

	@Override
	public void addProduct(Product p) {
		
		productDetails.add(p);
	}

	@Override
	public String updateProduct(Product p, String id) 
	{ 
		for(int i = 0; i < productDetails.size(); i++) {
		if(productDetails.get(i).equals(id)) {
			productDetails.set(i, p);
		}
		
	}
		return "updated";
		
	}

	@Override
	public void deleteProduct(String id)  {
		
		for(Product prod :productDetails) {
			if(prod.getProdid().equals(id))
		     {
			productDetails.remove(prod);
			break;
		     }
	       }
	 }	
}	