package com.cg.employeedetailslayer.service;

import java.util.ArrayList;

import com.cg.employeedetailslayer.dao.EmployeeDaoImpl;
import com.cg.employeedetailslayer.dao.IEmployeeDao;
import com.cg.employeedetailslayer.dto.Employee;

public class EmployeeServiceImpl implements IEmployeeService{
	
	private IEmployeeDao dao = new EmployeeDaoImpl();
	
	 public EmployeeServiceImpl() {
		
	 
		}
		
		 	
	@Override
	public ArrayList<Employee> getEmployeeDetails()
{
		
		return dao.getEmployeeDetails();
		
		
	}

	@Override
	public Employee getDetails(int empId) {
		
		return dao.getDetails(empId);
	}


	@Override
	public void addEmployee(Employee em) {
		
		dao.addEmployeeDaoImpl(em);
	}


	@Override
	public void updatesalary(int id1, double sal1) {
		
		dao.updatesalary(id1, sal1);
	}


	


	
}