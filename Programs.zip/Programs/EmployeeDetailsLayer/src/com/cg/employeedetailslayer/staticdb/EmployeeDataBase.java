package com.cg.employeedetailslayer.staticdb;

import java.util.ArrayList;

import com.cg.employeedetailslayer.dto.Employee;

public class EmployeeDataBase {

	private static ArrayList<Employee> arrList=null;
	
	static {
		arrList= new ArrayList<>();
	}


public static ArrayList<Employee>  getEmployeeDetails(){
	ArrayList<Employee> arrList=new ArrayList<>();
	
	Employee emp1=new Employee();	
	emp1.setEmpId(1001);
	emp1.setEmpName("shreya");
	emp1.setEmpSalary(15000);
	emp1.setEmpDesignation("Analyst");
	
	Employee emp2=new Employee();
	emp2.setEmpId(1002);
	emp2.setEmpName("reya");
	emp2.setEmpSalary(18000);
	emp2.setEmpDesignation("Senior Analyst");
	
	Employee emp3=new Employee();
	emp3.setEmpId(1003);
	emp3.setEmpName("sia");
	emp3.setEmpSalary(12000);
	emp3.setEmpDesignation("Junior");	
	
	Employee emp4=new Employee();
	emp4.setEmpId(1004);
	emp4.setEmpName("pia");
	emp4.setEmpSalary(5000);
	emp4.setEmpDesignation("Junior");	
	
	arrList.add(emp1);
	arrList.add(emp2);
	arrList.add(emp3);
	arrList.add(emp4);
		return arrList;
	
}




}

