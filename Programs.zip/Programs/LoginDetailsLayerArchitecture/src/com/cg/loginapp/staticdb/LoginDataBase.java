package com.cg.loginapp.staticdb;

import java.util.HashMap;

public class LoginDataBase {
	private static HashMap<String,String> hashMap=null;

	static {
	
	hashMap =new HashMap<>();
	
}
	public static HashMap<String,String>getLoginDetails() {
		hashMap.put("Shreya", "Admin");
		hashMap.put("Talukdar","Admin");
		return hashMap;
		
	}
	
	
	
	
}
