package com.cg.tms.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.tms.dto.TicketBean;

public class TestClass {
	
	TicketBean ticketbean=new TicketBean();

	@BeforeClass
	public static void setUpBeforeClass() throws Exception {
		System.out.println("Testing starts");
	}

	@AfterClass
	public static void tearDownAfterClass() throws Exception {
		System.out.println("Test is executed");
	}

	@Test
	public void raiseTicketTest() {
		ticketbean.setTicketDescription("The ticket not available");
		assertEquals("The ticket not available",ticketbean.getTicketDescription());
	}

}
