package com.cg.poly.service;
//parent class
public class Aone
{
final int a=10;
	public void getData()
	{
		int a=70;
		System.out.println("In getdata of A");
	}
	
}
