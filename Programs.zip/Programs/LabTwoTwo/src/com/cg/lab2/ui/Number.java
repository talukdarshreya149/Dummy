package com.cg.lab2.ui;

public class Number 
{
	int n;
 Number()
 {
	 
 }
 public int check_num(int n)
 { 
	 this.n=n;
	if(n>0)
	{
		System.out.println("Number is positive");
	}
	else
	{
		System.out.println("Number is negative");
	}
	return n;
 }
}
