package com.cg.prop;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class Proper {
public static void main(String[] args) throws FileNotFoundException, IOException {
	Properties properties=new Properties();
	properties
	.load(new FileReader(new File("D:/Users/learning/Desktop/file.properties")));
	System.out.println("S");
	System.out.println("dbid");
System.out.println("dbpassword");
}
}
