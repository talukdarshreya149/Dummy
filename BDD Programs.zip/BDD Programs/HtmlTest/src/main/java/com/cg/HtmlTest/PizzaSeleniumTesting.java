package com.cg.HtmlTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

import com.cg.util.DriverUtil;

public class PizzaSeleniumTesting {
	
	
private PizzaSeleniumTesting() {
		
	}

	public static void main(String[] args) {
		String baseUrl="D:\\BDD_Workspace\\HtmlTest\\WebContent\\pizza.html";
		DriverUtil driverUtil=new DriverUtil();
		WebDriver driver1=driverUtil.initiateDriver("Chrome");
		driver1.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
		driver1.get(baseUrl);
		driver1.manage().window().maximize();
		
		WebElement uname=driver1.findElement(By.name("uname"));
		uname.sendKeys("shreya");
			
		WebElement toppings=driver1.findElement(By.id("pizza"));
		toppings.click();
		
		Select sauce=new Select(driver1.findElement(By.id("sel")));
		sauce.selectByIndex(0);
		
		
		WebElement extra=driver1.findElement(By.name("extra"));
		extra.click();
		
		WebElement delivery=driver1.findElement(By.name("Delivery"));
		delivery.sendKeys("I want pizza quickly!");
		
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		
		WebElement sub=driver1.findElement(By.name("Login"));
		sub.click();
		try {
			Thread.sleep(1000);
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		
		
		driver1.close();
			
		
	}

}
