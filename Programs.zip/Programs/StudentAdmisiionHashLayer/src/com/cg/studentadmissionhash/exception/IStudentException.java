package com.cg.studentadmissionhash.exception;

public interface IStudentException {
	
	
	String ERROR1="Invalid Date";
String ERROR2="Invalid age";
String ERROR3="Invalid Student name";
String ERROR4 ="Invalid phone number ";
String ERROR5="invalid email";
}
