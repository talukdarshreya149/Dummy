package com.cg.HotelBooking;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.util.DriverUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelTest {

	private WebDriver driver;
	private HotelPojo pojo;
	private LoginPojo logpojo;
	DriverUtil util=new DriverUtil();
	
	
	@Before
	public  void initialize() throws Exception {
		driver=util.initiateDriver("Chrome");
		driver.manage().window().maximize();	
		pojo=new HotelPojo();
		PageFactory.initElements(driver, pojo);
		logpojo=new LoginPojo();
		PageFactory.initElements(driver,logpojo);
	}

	
	@Test
	public void test() throws Throwable {
		i_enter_username_password();
		i_go_to_registration_page_to_fill_details();
		i_validate_the_outcomes();
		i_get_success_page();
		
	}


@Given("^I enter username, password$")
public void i_enter_username_password() throws Throwable {
    driver.get("D:\\shreyajavaPractice\\HotelBooking\\login.html");
   
}

@When("^I go to registration page to fill details$")
public void i_go_to_registration_page_to_fill_details() throws Throwable {
	logpojo.setUsername("capgemini");
	logpojo.setPassword("capg1234");
	Thread.sleep(3000);
	logpojo.clickLogin();
	
}

@Then("^I validate the outcomes$")
public void i_validate_the_outcomes() throws Throwable {
   pojo.setFname("shreya");
   pojo.setLname("Talukdar");
   pojo.setEmail("shreya@gmail.com");
   pojo.setPhone("9234567890");
   pojo.setAddress("12/A Green park");
   pojo.setCity("Bangalore");
   pojo.setState("Karnataka");
   pojo.setPersons("4");
   pojo.setCardholdername("shreya");
   pojo.setDebitNo("1234567890123456");
   pojo.setCvv("007");
   pojo.setExpMonth("12");
   pojo.setExpYear("2025");
   
   Thread.sleep(3000);
 
}

@Then("^I get success page$")
public void i_get_success_page() throws Throwable {
    pojo.clickConfirm();
}

   @After
   public  void tearDownAfterClass() throws Exception {
	  Thread.sleep(3000);
	  driver.quit();
}

}
