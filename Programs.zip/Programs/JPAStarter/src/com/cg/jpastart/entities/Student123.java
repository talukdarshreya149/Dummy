package com.cg.jpastart.entities;

public class Student123 {

}
