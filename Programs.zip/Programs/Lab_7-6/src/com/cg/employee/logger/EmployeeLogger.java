package com.cg.employee.logger;

public class EmployeeLogger {

}
