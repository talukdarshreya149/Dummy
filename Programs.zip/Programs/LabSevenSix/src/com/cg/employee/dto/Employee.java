package com.cg.employee.dto;

import java.time.LocalDate;

public class Employee {
private int eid;
private String ename;
private String designation;
private double salary;
private LocalDate dob;
private String medicalScheme;
public int getEid() {
	return eid;
}
public void setEid(int eid) {
	this.eid = eid;
}
public String getEname() {
	return ename;
}
public void setEname(String ename) {
	this.ename = ename;
}

public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public LocalDate getDob() {
	return dob;
}
public void setDob(LocalDate dob) {
	this.dob = dob;
}
public String getMedicalScheme() {
	return medicalScheme;
}
public void setMedicalScheme(String medicalScheme) {
	this.medicalScheme = medicalScheme;
}

}
