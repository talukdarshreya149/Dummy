package com.cg.demosix.ui;

import com.cg.demosix.service.iEmployeeService;

public class MAIN {
	
public static void main(String[] args)
{
	iEmployeeService emp= new EmployeeService();
	System.out.println(emp.a);
	emp.getData();
	double data=emp.showData();
	System.out.println(data);
}
}
