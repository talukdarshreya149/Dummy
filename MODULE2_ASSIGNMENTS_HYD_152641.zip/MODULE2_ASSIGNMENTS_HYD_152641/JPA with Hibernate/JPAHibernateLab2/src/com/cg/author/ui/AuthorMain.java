package com.cg.author.ui;

import java.util.Scanner;

import com.cg.author.entities.Author;
import com.cg.author.service.AuthorService;
import com.cg.author.service.AuthorServiceImpl;

public class AuthorMain {
	public static void printDetails() {
		System.out.println("menu");
		System.out.println("1.Add");
		System.out.println("2.Update");
		System.out.println("3.Remove");
		System.out.println("4.Search");
	}

	public static void main(String[] args) {
		int choice = 0;
		Scanner scanner = new Scanner(System.in);
		AuthorService authorService = new AuthorServiceImpl();
		do {
			printDetails();
			System.out.println("Enter choice");
			choice = scanner.nextInt();
			Author author = new Author();
			switch (choice) {

			case 1:

				System.out.println("First name:");
				String fname = scanner.next();
				System.out.println("Last name:");
				String lname = scanner.next();
				System.out.println("Enter the phone number:");
				String phone = scanner.next();

				author.setFirstName(fname);
				author.setLastName(lname);
				author.setPhnNo(phone);
				authorService.addAuthor(author);
				break;
			case 2:
				System.out.println("Enter the author id:");
				int id1 = scanner.nextInt();
				author = authorService.findById(id1);
				System.out.println("Enter the first name you want to update:");
				String fname1 = scanner.next();
				System.out.println("Enter the last name you want to update:");
				String lname1 = scanner.next();
				author.setFirstName(fname1);
				author.setLastName(lname1);
				authorService.updateDetails(author);
				break;
			case 3:
				System.out.println("Enter the id you want ");
				int id2 = scanner.nextInt();
				author = authorService.findById(id2);
				authorService.removeAuthor(author);
				break;
			case 4:
				System.out.println("Enter the author you want to find:");
				int id3 = scanner.nextInt();
				author = authorService.findById(id3);
				System.out.println(author.getFirstName());
				System.out.println(author.getLastName());
				break;
			}
		} while (choice != 5);
scanner.close();
	}
}
