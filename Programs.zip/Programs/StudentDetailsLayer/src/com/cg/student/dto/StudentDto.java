package com.cg.student.dto;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class StudentDto {
	
	
private int stId;
private String stName;
private String stDob;

private int stPassyear;



public int getStId() {
	return stId;
}
public void setStId(int stId) {
	this.stId = stId;
}
public String getStName() {
	return stName;
}
public void setStName(String stName) {
	this.stName = stName;
}
public String getStDob() {
	return stDob;
}
public void setStDob(String stDob) {
	this.stDob = stDob;
}
public int getStPassyear() {
	return stPassyear;
}
public void setStPassyear(int stPassyear) {
	this.stPassyear = stPassyear;
}
}
