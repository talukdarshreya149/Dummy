package com.cg.demoabstact.ui;

public abstract class Shift {
	// abstract method
	public abstract void getLogin();
	public abstract void getLogOut();
//non abstract method
	public void printallData()
	{
		System.out.println("Non Abstract Method.....");
	}
}
