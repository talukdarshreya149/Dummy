package com.cg.loginapp.dao;

import com.cg.loginapp.dto.UserBean;
import com.cg.loginapp.exception.MyLoginException;

public interface ILoginDao {
public String getLoginPassword(UserBean userBean) throws MyLoginException;

}
