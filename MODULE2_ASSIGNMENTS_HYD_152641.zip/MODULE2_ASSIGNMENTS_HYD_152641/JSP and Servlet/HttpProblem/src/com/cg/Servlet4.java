package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/Servlet4")
public class Servlet4 extends HttpServlet {
	PrintWriter out=null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		out=response.getWriter();
		  
		String n=(String)request.getAttribute("name");
		String c=(String)request.getAttribute("cityName");
		String m=(String)request.getAttribute("mob");
		String courseList[]=(String[])request.getAttribute("course");
		out.println("<h1> name : "+n+"</h1>");
		out.println("<h1> city : "+c+"</h1>");
		out.println("<h1> Mobile : "+m+"</h1>");
	
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
