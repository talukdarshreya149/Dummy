package com.cg.demo8.ui;

public class EmployeeException extends Exception{
public EmployeeException()
{ 
	super();
}
public EmployeeException(String msg) {
	super(msg);
}
}