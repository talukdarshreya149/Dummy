package com.cg.poly.service;
//child or sub class
public class Bone extends Aone
{
	public void getData()
	{
		System.out.println("In getdata of B");
	}
}
