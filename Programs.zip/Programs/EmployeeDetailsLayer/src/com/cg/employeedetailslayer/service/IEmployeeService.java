package com.cg.employeedetailslayer.service;
import java.util.ArrayList;

import com.cg.employeedetailslayer.dto.Employee;
public interface IEmployeeService {
	
public ArrayList<Employee>getEmployeeDetails();

public Employee getDetails(int empId);
 public void addEmployee(Employee em);
 public void updatesalary(int id1,double sal1);
}
