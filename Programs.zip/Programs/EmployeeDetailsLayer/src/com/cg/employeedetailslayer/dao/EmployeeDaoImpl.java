package com.cg.employeedetailslayer.dao;

import java.util.ArrayList;

import com.cg.employeedetailslayer.dto.Employee;
import com.cg.employeedetailslayer.staticdb.EmployeeDataBase;

public class EmployeeDaoImpl implements IEmployeeDao{

	@Override
	public ArrayList<Employee> getEmployeeDetails() {
		
		return EmployeeDataBase.getEmployeeDetails();
	}

	@Override
	public Employee getDetails(int empId) {
	ArrayList<Employee> arr=EmployeeDataBase.getEmployeeDetails();
	Employee esearch =null;
	for(Employee emp:arr) {
		if(emp.getEmpId()==empId)
	esearch=emp;
		break;
		}
		return esearch;
}

	@Override
	public void addEmployeeDaoImpl(Employee em) {
	ArrayList<Employee>arrList=EmployeeDataBase.getEmployeeDetails();	
		arrList.add(em);
	}

	@Override
	public void updatesalary(int id1, double sal1) {
		ArrayList<Employee>arrList=EmployeeDataBase.getEmployeeDetails();
		for(Employee emp1:arrList) {
			if(emp1.getEmpId()==id1) {
				emp1.setEmpSalary(sal1);
			}
		}
	}
}