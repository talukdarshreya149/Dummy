package com.cg.labninetwo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class FileNumber {
	public static void main(String[] args) {
		try {
			
			
		FileReader fr=new FileReader("D:\\Users\\learning\\Desktop\\number.txt");
	   // FileWriter fw=new FileWriter("numbers123.txt");
	
		BufferedReader br=new BufferedReader(fr);
		
		Scanner sc=new Scanner(br);
		String number=sc.next();
		
		String[] str=number.split(",");
		for (String string : str) {
			
			int value=Integer.parseInt(string);
			if(value%2==0)
			{
				System.out.println(value);
			}
			
			
		}
		
		
		
		sc.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
