package com.cg.labelevenfive;

import java.util.Scanner;
import java.util.function.ToIntFunction;

public class MainFactorial {
public static void main(String[] args) {
	Scanner scanner=new Scanner(System.in);
	System.out.println("enter the number to find factorial");
	int number=scanner.nextInt();
	ToIntFunction<Integer> factorial=new Factorial()::calculate;
	System.out.println(factorial.applyAsInt(number));
	scanner.close();
}
}
