package com.cg.studentadmissionhash.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Scanner;

import com.cg.studentadmissionhash.dto.StudentDto;
import com.cg.studentadmissionhash.exception.StudentException;
import com.cg.studentadmissionhash.service.IStudentColService;
import com.cg.studentadmissionhash.service.StudentColService;

public class MainStudent 
{
public static void main(String[] args) throws StudentException {
	Scanner scanner=new Scanner(System.in);

	StudentDto std=new StudentDto();
	
	IStudentColService service=new StudentColService();	
	 DateTimeFormatter form=DateTimeFormatter.ofPattern("dd-MM-yyyy");
	 System.out.println("****Menu****");
	 System.out.println("1. To Add Student Details");
	 System.out.println("2. To View Student Details");
	int choice=0;
	 do {
		 
	 System.out.println("Enter choice");
	 choice=scanner.nextInt();
	 	 
	 switch(choice)
{
	 case 1:// add
		 
		 System.out.println("enter Student name");
		 String name=scanner.next();
		 System.out.println("enter Student phonenumber");
		 String phone=scanner.next();
		 System.out.println("enter Student email");
		 String email=scanner.next();
		 System.out.println("enter Student age");
		 int age=scanner.nextInt();
		 System.out.println("enter Student gender");
		 char gender=scanner.next().charAt(0);
		 System.out.println("enter Student city");
		 String city=scanner.next();
		 System.out.println("enter Student Appointment Date in pattern of dd-MM-yyyy");
		 String join=scanner.next();
		 LocalDate appdate=LocalDate.parse(join, form);
		try {
			if(service.validateName(name, age, join, email, phone)) {
				
		 std.setAppdate(appdate);
		 std.setAge(age);
		 std.setCity(city);
		 std.setEmail(email);
		 std.setGender(gender);
		 std.setPhone(phone);
		 std.setName(name);
		 boolean result=false;
		 Integer generatedId=service.addStudentDetails(std);
		 
		 System.out.println("your generatedID:"+ generatedId);
			}
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		break;
				 
	 case 2:
	
		 System.out.println("enter id");
	int studentId=0;
	studentId=scanner.nextInt();
	StudentDto dto=service.viewStudentDetails(studentId);
		 
		 break;
}
	 }
while(choice!=2);
	 scanner.close();
}	 

}
