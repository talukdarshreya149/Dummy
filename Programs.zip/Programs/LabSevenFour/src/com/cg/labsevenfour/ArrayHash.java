package com.cg.labsevenfour;

import java.util.HashMap;

import java.util.Scanner;

public class ArrayHash {
	
	public static HashMap<Integer,Integer> getSquares(int a[])
	{
	HashMap<Integer,Integer> mymap=new HashMap<Integer,Integer>();
	for (int i = 0; i < a.length; i++)
	{
	mymap.put(a[i], a[i]*a[i]);
	}
	
	System.out.println();
	return mymap;
	}

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int a[]=new int[5];
		
		for (int i = 0; i < 5; i++) 
		{
			a[i]=sc.nextInt();
		}
		sc.close();
		HashMap<Integer,Integer> result=new HashMap<Integer,Integer>();
		result=getSquares(a);
		System.out.println(result);
	}

}


