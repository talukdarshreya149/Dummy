package com.cg.labtentwotwo.exception;


	public class EmployeeException extends Exception {

		/**
		 * 
		 */
		private static final long serialVersionUID = 1L;

	}

