package com.cg.demosix.service;

public interface iEmployeeService
{
	public void getData();// public abstract
public double showData() ;// public abstract
int a=10; // static final
}
