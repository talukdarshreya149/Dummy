package com.cg.mypaymentapp.dao;

import java.util.Map;

import com.cg.mypaymentapp.bean.Customer;

public interface WalletDao {

	public String save(Customer customer);
	public Customer findOne(String mobileNo);
	public Map<String,Customer>getDetails();
	
}
