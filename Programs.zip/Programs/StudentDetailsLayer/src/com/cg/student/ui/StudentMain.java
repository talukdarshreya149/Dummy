package com.cg.student.ui;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.HashSet;
import java.util.Scanner;

import com.cg.student.dto.StudentDto;
import com.cg.student.exception.MyException;
import com.cg.student.service.IStudentService;
import com.cg.student.service.StudentServiceImpl;

public class StudentMain {


	public static void main(String [] args)
	{
		
		DateTimeFormatter formate=DateTimeFormatter.ofPattern("mm-dd-yyyy");
		IStudentService service=new StudentServiceImpl();
		int choice=0;
		String sname=null;
		String sdob=null;
		int spass;
		
	do {
		printDetails();
		System.out.println("*****Menu*****");
		System.out.println("1. To add Student details");
		System.out.println("2. to view all Student details");
		System.out.println("3. To view any Student");
		System.out.println("4. To delete Student Details");
		System.out.println("5. Exit");
		System.out.println("Enter your choice");
	Scanner scanner=new Scanner(System.in)	;
	choice=scanner.nextInt();
	switch(choice)
	
	{
	
	case 1: //Add
		
		StudentDto st1=new StudentDto();
		
		System.out.println("ENTER Student ID");
		int sid=scanner.nextInt();
		System.out.println("ENTER Student NAME");
		sname=scanner.next();
		System.out.println("ENTER Student DOB");
		 sdob=scanner.next();
		String date=scanner.next();
		LocalDate date1=LocalDate.parse(sdob, formate);
		System.out.println("ENTER Student PASSINGYEAR");
	 spass=scanner.nextInt();
		
		try {
									
		StudentDto dto=new StudentDto();
		
		if(service.validate(sname, sdob)){
			dto.setStName(sname);
			LocalDate datenew= LocalDate.parse(sdob, formate);
			dto.setStDob(sdob);
			dto.setStPassyear(spass);
			System.out.println("Generated ID is: "+ service.addStudent(dto)+ " ");
		}
		}catch(MyException e) {	
			
			System.out.println(e.getMessage());
		}
	
		break ;	
		
		
		
	case 2: //Show
		
		HashSet<StudentDto> allData=service.viewStudentDetails();
		for(StudentDto all: allData)
		{
			System.out.println("Student Id " + all.getStId());
			System.out.println("Student Name " + all.getStName());
			System.out.println("Student DOB " + all.getStDob());
			System.out.println("Student Passing year" + all.getStPassyear());
		}
	break;
	case 3: // Search Id
		
		System.out.println("Enter Student Id");
		int id=scanner.nextInt();
 StudentDto studSearch=service.searchStudent(id);
	if(studSearch.getStId()==0) {
		System.out.println("Student Not Found...");	
	}else
	{
		System.out.println("Student Id " + studSearch.getStId());
		System.out.println("Student Name " + studSearch.getStName());
		System.out.println("Student DOB " + studSearch.getStDob());
	System.out.println("Student Passing Year" + studSearch.getStPassyear());
	}

break;
	case 4: // Delete Student
		System.out.println("Enter Student Id");
		int rid=scanner.nextInt();
	service.deleteStudent(rid);
		break;
	case 5: //Exit
		System.exit(0);
break;
default: System.out.println("----Wrong Choice----");
	break;
		
	}
	scanner.close();
	}
	
	while(choice!=5);
	
	}
	
	
	
	

	public static  void printDetails()
	
	{
		System.out.println("1. Add Student...");
		System.out.println("2. Show All Student Details...");
		System.out.println("3. Search Student Id...");
		System.out.println("4. Delete Student...");
		System.out.println("5. Exit...");
	}
			
	
}

