package com.cg.studentadmissionhash.service;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Map;

import com.cg.studentadmissionhash.dao.IStudentColDao;
import com.cg.studentadmissionhash.dao.StudentColDaoImpl;
import com.cg.studentadmissionhash.dto.StudentDto;
import com.cg.studentadmissionhash.exception.IStudentException;
import com.cg.studentadmissionhash.exception.StudentException;

public class StudentColService implements IStudentColService {

	private IStudentColDao dao=null;

 public StudentColService() {
	// TODO Auto-generated constructor stub
	dao=new StudentColDaoImpl();
}
	
		public StudentDto viewStudentDetails(int studId) {
		// TODO Auto-generated method stub
		return dao.getStudentDetails().get(studId);
	}


	@Override
	public int addStudentDetails(StudentDto std) {
		// TODO Auto-generated method stub
		
		Map<String,String> collegedetails=dao.getCollegeDetails();
		if(collegedetails.containsKey(std.getCity())) {
     int generatedId=(int)(Math.abs(Math.random()*100000));
		
		std.setId(generatedId);
		std.setStatus("Approved");
		
		String city=std.getCity();
		String collegename=collegedetails.get(city);
		std.setCollegename(collegename);
		dao.addStudentDetails(std);
		}
	return std.getId();
	}


	@Override
	public boolean validateName(String name, int age, String date, String emailid, String phone)
			throws StudentException {
		// TODO Auto-generated method stub
		
		
		boolean result=false;
		if(name.trim().matches("[a-z][A-Z]"))
		{
			if(age>0 && age<100)
			{
				try {
				DateTimeFormatter form = DateTimeFormatter.ofPattern("dd-MM-yyyy");
				LocalDate.parse(date, form);
				if((phone+ " ").matches("\\d{10}"))
				{
					
				}else {
					throw new StudentException(IStudentException.ERROR4);
					
				}
				
				
			}catch(DateTimeParseException e) {
				
				throw new StudentException(IStudentException.ERROR1);
			}
				
			}else {
				throw  new StudentException(IStudentException.ERROR2);
			}
			
		}else
		{
			throw new  StudentException(IStudentException.ERROR3);
		}
		
		return false;
	}


	
	
}
