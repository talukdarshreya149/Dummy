package com.cg.library.service;

import java.util.List;
import java.util.Optional;

import com.cg.library.beans.Book;


public interface BookService {

	public List<Book> getAllBooks();
	public Optional<Book> getBookById(int id);
	public void addBook(Book b);
	public void updateBook(Book b, int id);
	public	void deleteBook(int id);
}
