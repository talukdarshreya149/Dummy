package com.cg.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletView
 */
@WebServlet("/ServletView")
public class ServletView extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
    public ServletView() {
        super();
        // TODO Auto-generated constructor stub
    }
    PrintWriter out=null;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		out=response.getWriter();
	String n=(String) request.getAttribute("txtName");
	String c=(String) request.getAttribute("txtCity");
	String m=(String) request.getAttribute("txtMobile");
	String u=(String) request.getAttribute("txtUsername");
	String e=(String) request.getAttribute("txtEmail");
	String g=(String) request.getAttribute("rdGender");
	
		out.println("<h1> name : " + n+ "</h1>");
		out.println("<h1> city : " + c+ "</h1>");
		out.println("<h1> mobile : " + m+ "</h1>");
		out.println("<h1> email : " + e+ "</h1>");
		out.println("<h1> username : " + u+ "</h1>");
		out.println("<h1> gender : " + g+ "</h1>");
		
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
