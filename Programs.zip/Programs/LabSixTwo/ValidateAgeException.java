package com.cg.lab6two.ui;

public class ValidateAgeException extends Exception {


public ValidateAgeException()
{ 
	super();
}
public ValidateAgeException(String msg) {
	super(msg);
}
}
