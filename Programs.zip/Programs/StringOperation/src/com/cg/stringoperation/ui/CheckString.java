package com.cg.stringoperation.ui;
import java.util.Scanner;
public class CheckString 
{
public static void main(String[] args)
{
	Scanner sc= new Scanner(System.in);
	String str= new String();
	str=sc.next();
	int len=str.length();
	boolean found=false;
	for(int i=0;i<=len-1;i++)
	{
		if(str.charAt(i)< str.charAt(i+1))
		{
			found=true;
					}
		else
			found= false;
		}
if(found==true)
{
	System.out.println("Positive");

}
else
	System.out.println("Negative");
sc.close();
}
}

