package com.cg.pojo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class MenuBeans {

	
	@FindBy(how=How.NAME,name="uname")
	private WebElement username;
	
	@FindBy(how=How.NAME, name="Design")
	private WebElement designation;
	
	@FindBy(how=How.NAME, name="country")
	private WebElement country;
	
	@FindBy(how=How.LINK_TEXT, linkText="Next")
	private WebElement nextLink;

	@FindBy(how=How.ID, id="Reset")
	private WebElement resetBtn;

	public String getUsername() {
		return username.getAttribute("value");
	}

	public void setUsername(String username) {
		this.username.sendKeys(username);
	}

	public String getDesignation() {
		return designation.getAttribute("value");
	}

	public void setDesignation(String designation) {
		this.designation.findElement(By.id(designation)).click();
	}

	public String getCountry() {
		return new Select(this.country).getFirstSelectedOption().getText();
	}

	public void setCountry(String country) {
		new Select(this.country).selectByVisibleText(country);
	}

	public void clickNext() {
		nextLink.click();
	}

	public void clickReset() {
		resetBtn.click();
	}

//	public WebElement getNextLink() {
//		return nextLink;
//	}
//
//	public void setNextLink(WebElement nextLink) {
//		this.nextLink = nextLink;
//	}
//
//	public WebElement getResetBtn() {
//		return resetBtn;
//	}
//
//	public void setResetBtn(WebElement resetBtn) {
//		this.resetBtn = resetBtn;
//	}

	
	
}
