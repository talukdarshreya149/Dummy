package com.cg.spring.boot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.spring.boot.dto.Product;
import com.cg.spring.boot.repo.ProductRepo;
import com.cg.spring.boot.repo.ProductRepoImpl;

@Service("productService")
public class ProductServiceImpl implements ProductService{
 
	@Autowired
	private ProductRepo repo;
 
      @Override
	public List<Product> getAllProducts() {
		
		return repo.getAllProducts();
	}

	@Override
	public Product getProductById(String id) {
	
		return repo.getProductById(id);
	}

	@Override
	public void addProduct(Product p) {
		repo.addProduct(p);
	}

	@Override
	public String updateProduct(Product p, String id) {
		return repo.updateProduct(p, id);
		
	}

	@Override
	public void deleteProduct(String id) {
		repo.deleteProduct(id);
	}

}
