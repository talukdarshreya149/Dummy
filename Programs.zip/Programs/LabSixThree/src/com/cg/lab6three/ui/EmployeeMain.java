package com.cg.lab6three.ui;

import java.util.Scanner;

import com.cg.eis.exception.EmployeeException;


public class EmployeeMain {


	
	public static void main(String [] args)
	{
		String des=new String();
		EmployeeSixThree emp= new EmployeeSixThree();
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter Employee Id ");
		int empId=sc.nextInt();
		System.out.println("Enter Employee Name ");
		String empName=sc.next();
		
		
		System.out.println("Enter Employee Salary ");
		double empSal= sc.nextDouble();
		
		try {
						
			emp.setEmpSal(empSal);
			} 
		catch (EmployeeException e) 
		{
				System.out.println(e.getMessage());
			
		}
	System.out.println(" Employee Designation");	
		des=sc.next();
	
	
	String scheme=new String();
	
	scheme=emp.checkScheme(des,empSal);


	System.out.println("*****EMPLOYEE DETAILS******  " );
		
	System.out.println("Employee Id " +  empId);
		System.out.println("Employee Name " +  empName);
		
		System.out.println("Employee Salary " +  empSal);
		
		System.out.println("Employee Designation " +  des);
				
		System.out.println("Employee Scheme " +  scheme);
		
	sc.close();
		

}
}

