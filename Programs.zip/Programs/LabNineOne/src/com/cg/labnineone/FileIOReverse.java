package com.cg.labnineone;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileIOReverse {
public static void main(String[] args) {
		
		try {
			FileReader fr=new FileReader("D:\\Users\\learning\\Desktop\\name.txt");
			FileWriter fw=new FileWriter("D:\\Users\\learning\\Desktop\\Reversedname.txt");
           BufferedReader br= new BufferedReader(fr);
			
			Scanner sc=new Scanner(br);
			String name=sc.next();
			
			StringBuilder sb=new StringBuilder(name);
			name=sb.reverse().toString();
			
			BufferedWriter bw=new BufferedWriter(fw);
			bw.write(name);
			bw.close();
			sc.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
}
