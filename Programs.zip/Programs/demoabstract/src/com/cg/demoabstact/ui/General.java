package com.cg.demoabstact.ui;

public class General extends Shift {

	@Override
	public void getLogin() {
		// TODO Auto-generated method stub
		System.out.println("Get LoginIn");
	}

	@Override
	public void getLogOut() {
		// TODO Auto-generated method stub
		System.out.println("Get LogOut");
	}

}
