package com.cg.thread;

public class Display {
	

public synchronized void wish(String name) {
		// TODO Auto-generated method stub
for(int i=0;i<10;i++) {
	System.out.print("hello  ");
try{
	Thread.sleep(2000);}
	catch(InterruptedException ie)
	{
		ie.printStackTrace();
	}
	System.out.println(name);
}

	}

	
}
