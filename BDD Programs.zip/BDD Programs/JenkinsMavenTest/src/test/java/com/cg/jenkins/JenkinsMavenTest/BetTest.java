package com.cg.jenkins.JenkinsMavenTest;

import static org.junit.Assert.*;

import org.junit.Test;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BetTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

@Given("^I have an account with cash balance of (\\d+)$")
public void i_have_an_account_with_cash_balance_of(int arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
    
}

@When("^I place a bet of (\\d+) on \"([^\"]*)\"$")
public void i_place_a_bet_of_on(int arg1, String arg2) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
   
}

@Then("^the bet should be placed successfully$")
public void the_bet_should_be_placed_successfully() throws Throwable {
    // Write code here that turns the phrase above into concrete actions
  
}

@Then("^the remaining balance in my account should be (\\d+)$")
public void the_remaining_balance_in_my_account_should_be(int arg1) throws Throwable {
    // Write code here that turns the phrase above into concrete actions
  
}


}
