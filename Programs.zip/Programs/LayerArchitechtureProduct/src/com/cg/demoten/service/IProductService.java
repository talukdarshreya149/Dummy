package com.cg.demoten.service;

import java.util.List;

import com.cg.demoten.dto.Product;

public interface IProductService {

	public void addProduct(Product pro);
	public List<Product>showAllProduct();
	public Product searchProduct(int prodid);
	public void removeProduct(int prorid);
	
	
}
