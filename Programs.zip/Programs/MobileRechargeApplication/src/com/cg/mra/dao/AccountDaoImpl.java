package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import com.cg.mra.userbean.Account;

public class AccountDaoImpl implements AccountDao{

public static HashMap<String,Account> hashmap=null;
	
	static {
		hashmap=new HashMap<>();
	}
	//------------------------    <NAme> Application --------------------------
		/*******************************************************************************************************
		 - Method Name	        :	<getAccount>
		 - Input Parameters	:	<mobilenNo)> <String>
		 - Return Type		:	<variable name> <data type>
		 - Throws		:  	<Application_name>Exception
		 - Author		:	<Your_name>
		 - Creation Date	:	dd/MM/yyyy
		 - Description		:	write description of the method in few lines
		 ********************************************************************************************************/


	@Override
	public Account getAccount(String mobileNo) {
		// TODO Auto-generated method stub
		
		Account account=new Account();
		
	 mobileNo=account.getMobileNo();
	hashmap.put(mobileNo,account);
		Set<Entry<String,Account>> set=hashmap.entrySet();
		Iterator<Entry<String,Account>> it=set.iterator();
		
		while(it.hasNext()) {
			Map.Entry<String,Account> entry=it.next();
			if(entry.getKey().equals(mobileNo)) {
				account=entry.getValue();
				break;
			}
		}
		return account;
	}
	//------------------------    <NAme> Application --------------------------
		/*******************************************************************************************************
		 - Method Name	        :	<rechargeAccount>
		 - Input Parameters	:	<mobileNo, rechargeAmount> <String, double>
		 - Return Type		:	<variable name> <data type>
		 - Throws		:  	<Application_name>Exception
		 - Author		:	<Your_name>
		 - Creation Date	:	dd/MM/yyyy
		 - Description		:	write description of the method in few lines
		 ********************************************************************************************************/
	@Override
	public int rechargeAccount(String mobileNo, double rechargeAmount) {
		// TODO Auto-generated method stub
		Account account=new Account();
		Set<Entry<String,Account>> set=hashmap.entrySet();
		Iterator<Entry<String,Account>> it=set.iterator();
		
		while(it.hasNext()) {
			Map.Entry<String,Account> entry=it.next();

mobileNo=entry.getKey();
				account=entry.getValue();
		}
 rechargeAmount=account.getRechargeAmount();
 double accountBalance=account.getAccountBalance();
 double newAccountbalance=accountBalance+rechargeAmount;
 return (int) newAccountbalance;
	}

}
