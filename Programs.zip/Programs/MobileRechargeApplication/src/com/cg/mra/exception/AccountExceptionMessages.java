package com.cg.mra.exception;

public interface AccountExceptionMessages {
	
	String ERROR1="Internal error";
	String ERROR2=" Mobile No doesnt exist...Try Again";
	String ERROR3="Cannot Recharge Amount  as given Mobile No doesnt exist...Try Again ";
}
