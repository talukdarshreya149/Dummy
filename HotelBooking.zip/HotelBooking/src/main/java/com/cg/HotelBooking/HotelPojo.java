package com.cg.HotelBooking;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.ui.Select;

public class HotelPojo 
{
	@FindBy(how=How.ID,id="txtFirstName")
	private WebElement fname;
	
	@FindBy(how=How.ID, id="txtLastName")
	private WebElement lname;
	
	@FindBy(how=How.ID,id="txtEmail")
	private WebElement email;
	
	@FindBy(how=How.ID, id ="txtPhone")
	private WebElement phone;

	@FindBy(how=How.ID, id="address")
	private WebElement address;
	
	@FindBy(how=How.NAME, name="city")
	private WebElement city;
	
    @FindBy(how=How.NAME, name="state")
    private WebElement state;
    
    @FindBy(how=How.NAME, name ="persons")
    private WebElement persons;
    
    @FindBy(how=How.ID, id="rooms")
    private WebElement rooms;
   
    @FindBy(how=How.ID, id ="txtCardholderName")
    private WebElement cardholdername;
    
    @FindBy(how=How.NAME, name="debit")
    private WebElement debitNo;
    
    @FindBy(how=How.ID, id ="txtCvv" )
    private WebElement cvv;

    @FindBy(how=How.ID, id="txtMonth")
    private WebElement expMonth;
    
    @FindBy(how=How.ID, id ="txtYear" )
    private WebElement expYear;
    
    @FindBy(how=How.ID, id ="btnPayment")
    private WebElement confirmBtn;

	public String getFname() {
		return fname.getAttribute("value");
	}

	public void setFname(String fname) {
		this.fname.sendKeys(fname);
	}

	public String getLname() {
		return lname.getAttribute("value");
	}

	public void setLname(String lname) {
		this.lname.sendKeys(lname);
	}

	public String getEmail() {
		return email.getAttribute("value");
	}

	public void setEmail(String email) {
		this.email.sendKeys(email);
	}

	public String getPhone() {
		return phone.getAttribute("value");
	}

	public void setPhone(String phone) {
		this.phone.sendKeys(phone);
	}

	public String getAddress() {
		return address.getAttribute("value");
	}

	public void setAddress(String address) {
		this.address.sendKeys(address);
	}

	public String getCity() {
		return new Select(this.city).getFirstSelectedOption().getText();
	}

	public void setCity(String city) {
		new Select(this.city).selectByVisibleText(city);
	}

	public String getState() {
		return new Select(this.state).getFirstSelectedOption().getText();
	}

	public void setState(String state) {
		new Select(this.state).selectByVisibleText(state);
	}

	public String getPersons() {
		return new Select(this.persons).getFirstSelectedOption().getText();
	}

	public void setPersons(String persons) {
		new Select(this.persons).selectByVisibleText(persons);
	}

	public String getRooms() {
		return rooms.getAttribute("value");
	}

	public void setRooms(String rooms) {
		this.rooms.sendKeys(rooms);
	}

	public String getCardholdername() {
		return cardholdername.getAttribute("value");
	}

	public void setCardholdername(String cardholdername) {
		this.cardholdername.sendKeys(cardholdername);
	}

	public String getDebitNo() {
		return debitNo.getAttribute("value");
	}

	public void setDebitNo(String debitNo) {
		this.debitNo.sendKeys(debitNo);
	}

	public String getCvv() {
		return cvv.getAttribute("value");
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}
	
	public String getExpMonth() {
		return expMonth.getAttribute("value");
	}

	public void setExpMonth(String expMonth) {
		this.expMonth.sendKeys(expMonth);
	}

	public String getExpYear() {
		return expYear.getAttribute("value");
	}

	public void setExpYear(String expYear) {
		this.expYear.sendKeys(expYear);
	}

	public void clickConfirm() {
		// TODO Auto-generated method stub
		confirmBtn.click();
	}
    
    
}
