package com.cg.jpaproduct.dao;

import java.util.List;

import com.cg.jpaproduct.dto.Product;

public interface IProductDao {
	
	
	
	public void addProductDao(Product pro);
	
	public List<Product>showAllProductDao();
	public Product searchProductDao(int prodid);
	public void removeProductDao(int prorid);
	

}
