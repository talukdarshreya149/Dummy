package com.cg.lab2.ui;
enum Gender{Male ("M"), Female("F");
String gender;
Gender(String gender)
{
	this.gender=gender;
	
}
}
public class PersonMain
{
	public static void main(String[] args)
	{
		
Person per= new Person();

per.setFirstName("Shreya");
per.setLastName("Talukdar");
per.setGender('F');
per.setPhone(456695345);
System.out.println(per.getFirstName());
System.out.println(per.getLastName());
System.out.println(per.getGender());
System.out.println(per.getPhone());
Gender g=null;
System.out.println(g.Male.gender);
}
}