package com.cg.eleventhree;


@FunctionalInterface
public interface IName {
	
	boolean name(String uname,long password);
	
}
