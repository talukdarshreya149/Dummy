package com.cg.mypaymentapp.service;

import java.math.BigDecimal;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.imageio.metadata.IIOInvalidTreeException;

import com.cg.mypaymentapp.bean.Customer;
import com.cg.mypaymentapp.dao.WalletDao;
import com.cg.mypaymentapp.dao.WalletDaoImpl;
import com.cg.mypaymentapp.exception.IInsufficientbalanceException;
import com.cg.mypaymentapp.exception.IInvalidInputException;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;

public class WalletServiceImpl implements WalletService {
	
private WalletDao dao=null;
	
	public WalletServiceImpl(){
		dao= new  WalletDaoImpl();
	}
	

	public void createAccount(Customer customer) {
		// TODO Auto-generated method stub
		dao.save(customer);
	}



	

	public Customer showBalance(String mobileno) {
		// TODO Auto-generated method stub
		return dao.getDetails().get(mobileno);
	}

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		Map<String,Customer> customerDetails=dao.getDetails();
		BigDecimal senderBal=customerDetails.get(sourceMobileNo).getWallet();
		senderBal=senderBal.subtract(amount);
		customerDetails.get(sourceMobileNo).setWallet(senderBal);
		BigDecimal receiverbal=customerDetails.get(targetMobileNo).getWallet();
		receiverbal=receiverbal.add(amount);
		customerDetails.get(targetMobileNo).setWallet(receiverbal);		
		return dao.getDetails().get(targetMobileNo);
	}

	public Customer depositAmount(String mobileNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		Map<String,Customer> customerDetails=dao.getDetails();
		Customer cust=new Customer();
		Set<Entry<String,Customer>> entryset=customerDetails.entrySet();
		Iterator<Entry<String,Customer>> it=entryset.iterator();
		while(it.hasNext()) {
			Map.Entry<String, Customer> entry=it.next();
			if(entry.getKey().equals(mobileNo)) {
				cust=entry.getValue();
				break;
			}
		}
		BigDecimal finalAmt=cust.getWallet().add(amount);
		cust.setWallet(finalAmt);
		return dao.getDetails().get(mobileNo);
	}

	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		// TODO Auto-generated method stub
		Map<String,Customer> customerDetails=dao.getDetails();
		Customer cust1=new Customer();
		Set<Entry<String,Customer>> entryset1=customerDetails.entrySet();
		Iterator<Entry<String,Customer>> it=entryset1.iterator();
		while(it.hasNext()) {
			Map.Entry<String, Customer> entry1=it.next();
			if(entry1.getKey().equals(mobileNo)) {
				cust1=entry1.getValue();
				break;
			}
		}
		BigDecimal finalAmt1=cust1.getWallet().subtract(amount);
		cust1.setWallet(finalAmt1);
		return dao.getDetails().get(mobileNo);
		
	}


	public boolean inputValidation(String name, String mobileNo) throws InvalidInputException {
		// TODO Auto-generated method stub
		boolean result=false;
		if(name.trim().matches("^[A-Z a-z]*$")) {
			if(mobileNo.length()==10) {
				result=true;
			}else {
				throw new InvalidInputException(IInvalidInputException.ERROR1);
			}
		}else {
			throw new InvalidInputException(IInvalidInputException.ERROR2);
		}
		return result;
	}


	public boolean balanceValidation(BigDecimal amount, String mobNo) throws InsufficientBalanceException {
		// TODO Auto-generated method stub
		boolean result=false;
		BigDecimal balance=dao.findOne(mobNo).getWallet();
		if(amount.compareTo(balance)==-1) {
			result=true;
			
		}else {
			throw new InsufficientBalanceException(IInsufficientbalanceException.ERROR1);
		}
		return result;
	}


	public boolean mobileValidation(String mobile) throws InvalidInputException {
		// TODO Auto-generated method stub
		 boolean result=false;
		 if(mobile.length()==10) {
			 result=true;
			 
		 } else {
			 throw  new InvalidInputException(IInvalidInputException.ERROR1);
		 }
		 
		 return result;
	}


	public boolean transferValidation(BigDecimal amount, String mobNoS) throws InsufficientBalanceException {
		// TODO Auto-generated method stub
		boolean result=false;
		BigDecimal bal1=dao.findOne(mobNoS).getWallet();
		if(amount.compareTo(bal1)==-1) {
			result=true;
		}else {
			throw new InsufficientBalanceException(IInsufficientbalanceException.ERROR2);
		}
		return result;
	}


	public boolean checkMobile(String mobileNo) {
		// TODO Auto-generated method stub
		return false;
	}





	
}
