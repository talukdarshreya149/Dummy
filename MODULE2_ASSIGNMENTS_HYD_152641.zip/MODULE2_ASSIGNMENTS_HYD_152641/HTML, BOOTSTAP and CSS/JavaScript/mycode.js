
function checkMandatory()
{

//this is single line comment
var fn=document.getElementById("txtFN").value;
var sn=document.getElementById("txtSN").value;
  if(fn!="" && sn!="")
    return true;
  else if(fn=="")
    {
    alert("Enter first number"); 
    return false;
	}
  else if(sn=="")
  {
  alert("Enter second number");
    return false;
  }
 
}

function AddNum()
{
var fn=document.getElementById("txtFN").value;
var sn=document.getElementById("txtSN").value;
if(checkMandatory())
{
var result=parseInt(fn)+parseInt(sn);
document.getElementById("txtResult").value=result;
}
}
function SubNum()
{
var fn=document.getElementById("txtFN").value;
var sn=document.getElementById("txtSN").value;
if(checkMandatory())
{
var result=parseInt(fn)-parseInt(sn);
document.getElementById("txtResult").value=result;
}
}

function ProdNum()
{
var fn=document.getElementById("txtFN").value;
var sn=document.getElementById("txtSN").value;
if(checkMandatory())
{
var result=parseInt(fn)*parseInt(sn);
document.getElementById("txtResult").value=result;
}
}

function DivNum()
{
var fn=document.getElementById("txtFN").value;
var sn=document.getElementById("txtSN").value;
if(checkMandatory())
{
var result=parseInt(fn)/parseInt(sn);
document.getElementById("txtResult").value=result;
}
}


function PowNum()
{
var fn=document.getElementById("txtFN").value;
var sn=document.getElementById("txtSN").value;

if(checkMandatory())

{
 var result=1;
  for(var i=1;i<=sn;i++)
  {
result=result*fn;
  }
document.getElementById("txtResult").value=result;
 }
}

function ClearNum()
{
var result='';
document.getElementById("txtResult").value=result;
document.getElementById("txtFN").value=result;
document.getElementById("txtSN").value=result;
}