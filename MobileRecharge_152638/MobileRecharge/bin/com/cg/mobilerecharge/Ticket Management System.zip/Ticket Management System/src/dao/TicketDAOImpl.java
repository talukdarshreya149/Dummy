package dao;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import dto.TicketBean;
import dto.TicketCategory;
import util.Utill;

public class TicketDAOImpl implements TicketDAO {

	private static Map<String, TicketBean> TicketLog = null;
	static {
		TicketLog = new HashMap<>();
	}

	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) {
		TicketLog.put(ticketBean.getTicketNo(), ticketBean);
		return true;
	}

	@Override
	public List<TicketCategory> listTicketCategory() {
		// TODO Auto-generated method stub
		List<TicketCategory> list = new ArrayList<>();

		TicketCategory category1 = new TicketCategory();
		category1.setCategoryName(Utill.getTicketCategoryEntries().get("tc001"));
		category1.setTicketCategoryId("1");

		TicketCategory category2 = new TicketCategory();
		category2.setCategoryName(Utill.getTicketCategoryEntries().get("tc002"));
		category2.setTicketCategoryId("2");

		TicketCategory category3 = new TicketCategory();
		category3.setCategoryName(Utill.getTicketCategoryEntries().get("tc003"));
		category3.setTicketCategoryId("3");

		list.add(category1);
		list.add(category2);
		list.add(category3);

		return list;
	}

}
