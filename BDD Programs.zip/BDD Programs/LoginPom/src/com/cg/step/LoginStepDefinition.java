package com.cg.step;

import static org.junit.Assert.*;

import org.junit.After;

import org.junit.Before;

import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.pojo.LoginBeans;
import com.cg.util.DriverUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepDefinition {

	private WebDriver driver;
	private LoginBeans loginbeans;
	DriverUtil util=new DriverUtil();
	
	@Before
	public void Initialization() {
			
		/*driver = new ChromeDriver();	*/
		
		driver=util.initiateDriver("Chrome");
		driver.manage().window().maximize();	
		loginbeans=new LoginBeans();
		PageFactory.initElements(driver, loginbeans);
	}

	@After
	public  void tearDownAfterClass() throws Exception {
		
	}

	@Test
	public void testLogin() throws Throwable {
	
		try {
			  i_need_to_enter_username_and_password();
			  i_give_the_username_and_password();
			  the_inputs_are_valid();
			  i_get_login_successful_message();
			
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

@Given("^I need to enter username and password$")
public void i_need_to_enter_username_and_password() throws Throwable {
    driver.get("D:\\BDD_Workspace\\LoginPom\\WebContent\\loginform.html");
}

@When("^I give the username and password$")
public void i_give_the_username_and_password() throws Throwable {
    loginbeans.setUsername("shreya");
    loginbeans.setPassword("shreya");
    loginbeans.clickNextPageLink();

    //    Alert alert=driver.switchTo().alert();
//    alert.getText();
//    alert.accept();
}

@Then("^the inputs are valid$")
public void the_inputs_are_valid() throws Throwable {
   
}

@Then("^I get login successful message$")
public void i_get_login_successful_message() throws Throwable {
    Thread.sleep(1000);
}


}
