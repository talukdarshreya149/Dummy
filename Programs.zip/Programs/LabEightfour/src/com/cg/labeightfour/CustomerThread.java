package com.cg.labeightfour;

public class CustomerThread implements Runnable{

static Thread thread1=new Thread(new CustomerThread());
static Thread thread2=new Thread(new CustomerThread());

public static void main(String[] main) {
	
	thread1.start();
	try {
		
		thread2.join();
	}catch(InterruptedException e) {
		e.printStackTrace();
		
	}
}
			
	@Override
	public void run() {
		// TODO Auto-generated method stub
	synchronized (thread1) {
	
		System.out.println("Customer giving productsto billing person");
		
	}
	synchronized (thread2) {
	System.out.println("Billing person bills the products");	
	}
	}

}
