package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ServletView3
 */
@WebServlet("/ServletView3")
public class ServletView3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	
	PrintWriter out=null;
   
    public ServletView3() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		HttpSession ses=request.getSession();
		
		out=response.getWriter();
		/*String n=(String) request.getAttribute("txtName");
		String c=(String) request.getAttribute("txtCity");
		String m=(String) request.getAttribute("txtMobile");
		String e=(String) request.getAttribute("txtEmail");
		*/

		String n=(String) ses.getAttribute("txtName");
		String c=(String) ses.getAttribute("txtCity");
		String m=(String) ses.getAttribute("txtMobile");
		String e=(String) ses.getAttribute("txtEmail");
		
		out.println("<h1> name : " + n+ "</h1>");
		out.println("<h1> city : " + c+ "</h1>");
		out.println("<h1> mobile : " + m+ "</h1>");
		out.println("<h1> email : " + e+ "</h1>");
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
