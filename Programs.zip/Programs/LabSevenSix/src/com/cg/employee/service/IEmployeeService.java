package com.cg.employee.service;

import com.cg.employee.dto.Employee;

public interface IEmployeeService {
	public void addDetails(Employee emp) throws Exception;

	public Employee getEmployeeDetails(String scheme1) throws Exception;
	}

