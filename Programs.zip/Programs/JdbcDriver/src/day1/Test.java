package day1;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;

import oracle.jdbc.OracleDriver;

/* *testing whether java program is able to connect
 *Programmatically with oracle database or not 
 */
@SuppressWarnings("unused")
public class Test {

	public static void main(String[] args) {
		try {
		OracleDriver driver =
				new OracleDriver();
		//instantiated the database driver
		
		//loading/registering the driver 
	//	Driver driver1 = new Driver();
		//Driver is an interface
		
		//DriverManager.registerDriver(Driver)
			DriverManager.registerDriver(driver);
			//@localhost if you are using oracle express edition 
			//instead of 10.51.103.201
			//XE instead of orcl11g
			
			
			Connection con =
					DriverManager.getConnection("jdbc:oracle:thin:@10.109.2.170:1521:XE","System","Capgemini123");
			
			System.out.println(con);
			//if u get null, it means connection with the 
			//Database was not established 
			
		} catch (SQLException e) {
			
			e.printStackTrace();
		}
		//classname.methodname
		
		//compiler is not complaining 
		//that String.class is not found
		//why ?
	}
}
