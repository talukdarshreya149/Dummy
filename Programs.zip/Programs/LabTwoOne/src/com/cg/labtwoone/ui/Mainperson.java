package com.cg.labtwoone.ui;

public class Mainperson {
	


	public static void main(String[] args)
		{
			PersonOne	per= new PersonOne();
			per.printAllDetails();
			
		}

	}

