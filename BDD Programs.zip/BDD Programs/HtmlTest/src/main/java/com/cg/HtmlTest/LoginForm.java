/*package com.cg.HtmlTest;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class LoginForm {

	public static void main(String [] args) throws InterruptedException {
		
		String baseUrl="D:\\SELENIUM\\loginform.html";
	System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe" );
	WebDriver driver=new ChromeDriver();
	driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS);
	driver.get(baseUrl);
	driver.manage().window().maximize();
	WebElement uname=driver.findElement(By.name("uname"));
	uname.sendKeys("shreya");
	WebElement pass=driver.findElement(By.name("pass"));
	
	pass.sendKeys("shreya");
	Thread.sleep(2000);
	WebElement sub=driver.findElement(By.name("sub"));
	sub.click();
	Thread.sleep(2000);
	
	System.out.println("Page title is: " + driver.getTitle());
	driver.quit();
		
	}
	
}

*/
