package com.cg.demoten.service;

import java.util.List;

import com.cg.demoten.dao.IProductDao;
import com.cg.demoten.dao.ProductDaoImpl;
import com.cg.demoten.dto.Product;

public class ProductService implements IProductService
{
	IProductDao dao=new ProductDaoImpl();

	@Override
	public void addProduct(Product pro) {
		// TODO Auto-generated method stub
		dao.addProductDao(pro);
	}

	@Override
	public List<Product> showAllProduct() {
		// TODO Auto-generated method stub
		return dao.showAllProductDao();
	}

	@Override
	public Product searchProduct(int prodid) {
		// TODO Auto-generated method stub
		return dao.searchProductDao(prodid);
	}

	@Override
	public void removeProduct(int prorid) {
		// TODO Auto-generated method stub
		 dao.removeProductDao(prorid);
	}

	
}
