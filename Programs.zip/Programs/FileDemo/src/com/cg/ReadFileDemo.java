package com.cg;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class ReadFileDemo {

	public static void main(String[] args)  {
		FileInputStream fileinputStream=null;
		StringBuilder stringBuilder=new StringBuilder();
		try {
	 fileinputStream= new FileInputStream(new File("D://Java/lab2.txt"));
	int data;
	 
	 while((data=fileinputStream.read())!=-1) {
		 
				System.out.print((char)data);
		}
		fileinputStream.close();
	}catch(FileNotFoundException e) {
		System.out.println("Sorry! file is missing");
	} catch (IOException e) {
				System.out.println("Reading Failed!!");
			}
		
	System.out.println(stringBuilder);
FileOutputStream fileoutputStream=null;
try {
fileoutputStream =new FileOutputStream(new File("D://Java/Employee.txt "));

fileoutputStream.write(stringBuilder.toString().getBytes());
fileoutputStream.close();
	}catch(FileNotFoundException e) {
		System.out.println("Sorry! file is missing");
	} catch (IOException e) {
				System.out.println("Writing Failed!!");
			}	
	}
}
