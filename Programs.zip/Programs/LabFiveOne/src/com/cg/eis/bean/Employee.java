package com.cg.eis.bean;

public class Employee 
{
	
 public int empId;
 public String empName;
 public double empSal;
 public String empDesign;
 public String inScheme;
 
}
