package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/Servlet1.do")
public class Servlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Servlet1() {
        super();
        
    }
    PrintWriter out=null;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		out=response.getWriter();
		String n=request.getParameter("txtName").trim();
		String c=request.getParameter("txtCity").trim();
		String m=request.getParameter("txtMobile").trim();
		String e=request.getParameter("txtEmail").trim();
	
		HttpSession session=request.getSession(true);
		System.out.println(session);
		
		/*request.setAttribute("txtName",n);
		request.setAttribute("txtCity",c);
		request.setAttribute("txtMobile",m);
		request.setAttribute("txtEmail",e);
		*/
		
		session.setAttribute("txtName",n);
		session.setAttribute("txtCity",c);
		session.setAttribute("txtMobile",m);
		session.setAttribute("txtEmail",e);
		
		request.getRequestDispatcher("ServletView1").forward(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
