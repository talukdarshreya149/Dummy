package com.cg.mypaymentapp.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.mypaymentapp.bean.Customer;
import com.cg.mypaymentapp.repo.WalletRepository;

@Service
public class WalletServiceImpl implements WalletService {

	@Autowired
	private WalletRepository repo;
	
	@Override
	public void createAccount(Customer customer) {
		repo.save(customer);

	}

	@Override
	public Optional<Customer> showBalance(String mobileno) {
		return repo.findById(mobileno);
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) {

		Optional<Customer> customer1 = repo.findById(sourceMobileNo);
		Optional<Customer> customer2 = repo.findById(targetMobileNo);

		BigDecimal senderBal = customer1.get().getWallet().subtract(amount);
		String senderTrans=customer1.get().getTransaction()+"\n Withdrawn: "+amount+"\n"+"Remaining Balance: "+senderBal;
		customer1.get().setTransaction(senderTrans);
		
		BigDecimal receiverBal = customer2.get().getWallet().add(amount);
		String receiverTrans=customer2.get().getTransaction()+"\n Deposited: "+amount+"\n"+"Remaining Balance: "+receiverBal;
		customer2.get().setTransaction(receiverTrans);

		customer1.get().setWallet(senderBal);
		customer2.get().setWallet(receiverBal);
		
		Customer cust = repo.save(customer1.get());
		repo.save(customer2.get());

		return cust;
	}

	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) {

		Optional<Customer> customer = repo.findById(mobileNo);

		BigDecimal finalAmt = customer.get().getWallet().add(amount);
		String sender=customer.get().getTransaction()+"\n Deposited: "+amount+"\n"+"Remaining Balance: "+finalAmt;
		customer.get().setTransaction(sender);
		customer.get().setWallet(finalAmt);
		Customer cust = repo.save(customer.get());
		return cust;
	}

	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		Optional<Customer> customer = repo.findById(mobileNo);
		BigDecimal finalAmt = customer.get().getWallet().subtract(amount);
		String sender=customer.get().getTransaction()+"\n Withdrawn: "+amount+"\n"+"Remaining Balance: "+finalAmt;
		customer.get().setTransaction(sender);
		customer.get().setWallet(finalAmt);
		Customer cust = repo.save(customer.get());

		return cust;
	}

	@Override
	public String printTransaction(String mobile) {
	Optional<Customer> transaction=repo.findById(mobile);
	Customer customer=new Customer();
	  
	     if(transaction.isPresent()) {
		customer=transaction.get();
	}
		
		return customer.getTransaction();
	}

}
