package com.cg;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class Servlet1
 */
@WebServlet("/Servlet1.do")
public class Servlet1 extends HttpServlet {
	
	
	
	
	
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
			String n=request.getParameter("name").trim();
			String c=request.getParameter("city").trim();
			String m=request.getParameter("mobile").trim();
		
			HttpSession session=request.getSession(true);
			System.out.println(session);
			session.setAttribute("name",n);
			session.setAttribute("cityName",c);
			session.setAttribute("mob",m);
		/*	request.setAttribute("name",n);
			request.setAttribute("cityName",c);
			request.setAttribute("mob",m);
		*/	
			request.getRequestDispatcher("Servlet2").forward(request, response);
		}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
