package com.cg.democompare.ui;

public class Product implements Comparable<Product>
{
	private int prodID;
	private String prodNAME;
	private double prodPRICE;
	
	
	public int getProdID() {
		return prodID;
	}
	public void setProdID(int prodID) {
		this.prodID = prodID;
	}
	public String getProdNAME() {
		return prodNAME;
	}
	public void setProdNAME(String prodNAME) {
		this.prodNAME = prodNAME;
	}
	public double getProdPRICE() {
		return prodPRICE;
	}
	public void setProdPRICE(double prodPRICE) {
		this.prodPRICE = prodPRICE;
	}
	
	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return "Product[prodID= "+ prodID + ", prodName=" + prodNAME + ", prodPrice=" + prodPRICE+ "]";
	}
	
	public int compareTo( Product o)
	{
		// TODO Auto-generated method stub
		
		
		if(this.getProdID()>o.getProdID())
		{
			return 1;
		}
		else if(this.getProdID()<o.getProdID())
		{
			return -1;
		}
		else
		return 0;
	}
		
	

}
