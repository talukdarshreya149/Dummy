package com.cg.demo.service;


public class MyMain 
{
	public static void main(String [] args)
	{
		B temp=new B(10);
	System.out.println(temp);
	}

	
}
