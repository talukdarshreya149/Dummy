package com.cg.thread;

public class DemoThread extends Thread {

	public void run() {
		//Thread.currentThread().setName("Best");
		//System.out.println(Thread.currentThread().getName());
		//for (int i = 1; i <= 5; i++) {
			//System.out.println("Shreya");
		for(int i=0;i<15;i++) {
	
		System.out.println("bla bla bla.....1");
		System.out.println("bbl bla bla.....2");
		System.out.println("bbl bla bla.....3");
		System.out.println("bbl bla bla.....4");
		System.out.println("bbl bla bla.....5");
		}
		
		//}
	}

	public static void main(String[] args) throws InterruptedException{
		System.out.println("hi");
		System.out.println("welcome");
		DemoThread demo = new DemoThread();
		//DemoThread dem = new DemoThread();
		demo.start();
		try {
			
		demo.join();
		}catch(InterruptedException e) {
			e.printStackTrace();
		}
		
		//dem.start();
		//System.out.println(Thread.currentThread().getName());
		//for (int i = 1; i <= 5; i++) {
			//System.out.println("Bongo");
		//}
System.out.println("thank you");
System.out.println("byeee");
	}
}
