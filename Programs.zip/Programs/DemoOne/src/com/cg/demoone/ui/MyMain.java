package com.cg.demoone.ui;

public class MyMain 
{

	public static void main(String[] args)
{
		int numberOne=Integer.parseInt(args[0]);
		int numberTwo=Integer.parseInt(args[1]);
		
Calculator cal = new Calculator();
int addResult= cal.addNumber(numberOne,numberTwo);
int subResult= cal.subNumber(numberOne,numberTwo);
int mulResult= cal.mulNumber(numberOne,numberTwo);
int divResult= cal.divNumber(numberOne,numberTwo);

System.out.println("Addition of two numbers is "+ addResult  + " Subtraction of two numbers is" + subResult  + " Multiplication of two numbers is" + mulResult  + " Division of two number is" +  divResult);
}
}                 