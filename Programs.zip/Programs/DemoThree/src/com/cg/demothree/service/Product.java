package com.cg.demothree.service;

public class Product {

}
