package com.cg.mra.ui;

import java.util.Scanner;

import com.cg.mra.exception.AccountException;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;
import com.cg.mra.userbean.Account;

//------------------------    <Mobile_recharge> Application --------------------------
	/*******************************************************************************************************
	 - Method Name	        :	<Main _Class>
	 - Input Parameters	:	<variable name(s)> <data type(s)>
	 - Return Type		:	<variable name> <data type>
	 - Throws		:  	<Application_name>Exception
	 - Author		:	<Shreya_Talukdar_152641>
	 - Creation Date	:	11/07/2018
	 - Description		:	write description of the method in few lines
	 ********************************************************************************************************/

public class MainUI {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scanner=new Scanner(System.in);

AccountService accountService=new AccountServiceImpl();
int choice=0;

do {

	Account account=new Account();
	printDetails();
	
	choice=scanner.nextInt();
	switch(choice) {
	
		case 1: // accept details from user
		try {		
		System.out.println("Enter mobile number");
		String mobilenum=scanner.next();
		System.out.println("enter account balance");
		double accountbal=scanner.nextDouble();
		System.out.println("Enter account name");
		String name=scanner.next();
		System.out.println("Enter recharge amount");
		double rechargeAmt=scanner.nextDouble();
		
		if(accountService.validate(mobilenum, rechargeAmt))
		{
			account.setMobileNo(mobilenum);
			account.setCustomerName(name);
			account.setAccountBalance(accountbal);
			account.setRechargeAmount(rechargeAmt);
			
			accountService.getAccountDetails(mobilenum);
			accountService.rechargeAccount(mobilenum, rechargeAmt);
		}
		   }catch(AccountException e)
		{
			System.out.println(e.getMessage());
		}
		break;
			
	case 2: // recharge amount
		
		System.out.println("Member Name: "+account.getCustomerName());
		
		System.out.println("Member Account:" + account.getAccountBalance());	
		
		System.out.println("enter mobile number");
		String mobileNo1=scanner.next();
		System.out.println("Enter recharge amount");
		double rechargeAmt=scanner.nextDouble();
		 double newAccountBalance=accountService.rechargeAccount(mobileNo1, rechargeAmt);
		 
		 System.out.println("Your Account Recharge Successfully");
		 System.out.println(" Hello user!! Available Balance :"+ newAccountBalance);
		
		break;
		
		
		
	case 3:
		System.exit(0);
	}
	
	
}while(choice!=3);



	}

	
	
	public static void printDetails() {
		System.out.println("***Menu***");
		System.out.println("1. Account Balance Enquiry");
		System.out.println("2. Recharge Account");
		System.out.println("3. To Exit");
	}
}
