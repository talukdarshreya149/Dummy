package com.cg.mra.service;

import com.cg.mra.exception.AccountException;
import com.cg.mra.userbean.Account;

public interface AccountService {

	public Account getAccountDetails(String mobileNo);
	
	public int rechargeAccount(String mobileno, double rechargeAmount);
	public boolean validate(String mobileNo, double rechargeAmount)throws AccountException;
}
