package com.cg.lab4.ui;

import java.util.Random;
import java.util.Scanner;

public class AccMain 
{
	public static void main(String[] args)
	{
		Scanner sc= new Scanner(System.in);
		Account a1=new Account();
		Account a2=new Account();
		a1.setName("KATHY");
		a2.setName("SMITH");
a1.setBalance(3000);
a2.setBalance(2000);
Random r=new Random();
long val=r.nextInt(10000);
a1.setAccNum(val);
a2.setAccNum(val);
a1.setAge(22);
a2.setAge(23);
double b1=a1.getBalance();
double b2=a2.getBalance();
do {
	System.out.println("Enter name of Account Holder");
	String str= sc.next();
	System.out.println("** Menu **");
	System.out.println("1.Deposit");
	System.out.println("2.Withdraw");
	System.out.println("3.Show Balance");
	System.out.println("4.exit");
	
	if(str.equalsIgnoreCase("Kathy")) {
		System.out.println("Account Number" + a1.getAccNum());
		System.out.println("Age"+ a1.getAge());
		System.out.println("Enter your choice");
		int ch1=sc.nextInt();
		switch(ch1)
		{
		case 1: System.out.println("Enter the amount you want to deposit");
		double balance= sc.nextDouble();
		
		double x=a1.deposit(b1, balance);
		System.out.println("Current Balance " + x);
		b2=b2+balance;
		break;
		case  2: System.out.println("Enter then amount to withdraw");
		double balance1= sc.nextDouble();
		double x1=a1.deposit(b2, balance1);
		System.out.println("Current Balance " + x1);
		b2=b2-balance1;
		break;
		case 3: double x2=a2.showBalance(b2); 
			System.out.println("Current Balance " + x2);
			break;
		case 4: System.out.println("Thank You");
		System.exit(0);
		break;
		default: System.out.println("Wrong choice");
		}
		}
		else
		{
			
			System.exit(0);
		}
	System.out.println("Do you want to continue : (yes/no)");
	
String choice=sc.next();
if(choice.equalsIgnoreCase("yes"))
{
	continue;
}
else
{
	break;
}
} while(true);
sc.close();
	}
}