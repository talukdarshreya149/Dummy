/**
 * 
 */
package com.cg.loginapp.exception;

/**
 * @author learning
 *
 */
public interface IMyLoginExceptionMessages {

	String ERROR1 = " Internal Error.Try Again";

}
