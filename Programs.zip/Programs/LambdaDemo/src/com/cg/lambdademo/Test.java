package com.cg.lambdademo;

public class Test {
public static void main(String [] args) {
/*	IDemoLambda addition=(a,b)->( a+b);
	int result=addition.add(10, 20);
	System.out.println(result);
*/
	IDemoLambda demo=(a,b)->{ // for multiple lines execution
		System.out.println("Yaayy");
		System.out.println("Wohooo");
		System.out.println(a+b);
		
	};
		demo.add(100, 200);
		}
}
