package com.cg.demosix.dto;

public class Employee {
	private int empid;
	private String empName;
	private double empSalary;
	Project proj;
	public Employee()
	{
		
	}
	
	public Employee(int empid,String empName,double empSalary)
	{
		
	}
	public Project getProj() {
		return proj;
	}

	public void setProj(Project proj) {
		this.proj = proj;
	}

	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	

}
