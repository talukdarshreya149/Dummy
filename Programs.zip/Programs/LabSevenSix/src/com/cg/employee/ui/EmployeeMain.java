package com.cg.employee.ui;

import java.util.Scanner;

import com.cg.employee.dto.Employee;
import com.cg.employee.service.EmployeeService;
import com.cg.employee.service.IEmployeeService;

public class EmployeeMain {
	public static void printDetails() {
		System.out.println("***MENU****");
		System.out.println("1.Enter employee details ");
		System.out.println("2.Display Employee based on scheme");
		System.out.println("3.View All Employee");
	}

	public static void main(String[] args){
		Scanner scanner = new Scanner(System.in);
		int choice = 0;
		do {
			printDetails();
			IEmployeeService employeeService = new EmployeeService();
			Employee employee = new Employee();
			System.out.println("Enter your choice:");
			choice = scanner.nextInt();
			switch (choice) {
			case 1:
				
				System.out.println("Enter employee name:");
				String name = scanner.next();
				System.out.println("Enter employee Medical Scheme");
				String scheme = scanner.next();
				System.out.println("Enter designation");
				String desg = scanner.next();
				System.out.println("Enter salary");
				double salary = scanner.nextDouble();

				
				employee.setEname(name);
				employee.setMedicalScheme(scheme);
				employee.setSalary(salary);
				employee.setDesignation(desg);

				try {
					employeeService.addDetails(employee);
				} catch (Exception e) {
					
					e.printStackTrace();
				}
				break;
			case 2:
				System.out.println("Enter the medical Scheme");
				String scheme1 = scanner.next();
				Employee employee1;
				try {
					employee1 = employeeService.getEmployeeDetails(scheme1);
					System.out.println(employee1.getEid());
					System.out.println(employee1.getDesignation());
					System.out.println(employee1.getEname());
					System.out.println(employee1.getSalary());
					System.out.println(employee1.getDob());
				} catch (Exception e) {
					
					e.printStackTrace();
				}
			case 3:
				

			}

		} while (choice != 5);
		scanner.close();
	}

}
