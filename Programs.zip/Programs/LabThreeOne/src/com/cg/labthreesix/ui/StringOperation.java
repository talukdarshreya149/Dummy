package com.cg.labthreesix.ui;

public class StringOperation {
public String str1;
	
	StringOperation()
	{
		
	}
	
public void addString(String str1)
{
	this.str1=str1;
	System.out.println(str1.concat(str1));
}
public void hashOdd(String str1)
{
	this.str1=str1;
	int len=str1.length();
	for(int i=0;i<=len-1;i++)
	{
		if(i%2==0)
		{
			continue;
	
}
		else
		{
			str1=str1.substring(0, i-1)+'#'+ str1.substring(i,len);
		}
	}
	System.out.println(str1);
}
	public void duplicateChar(String str1)
	{
	this.str1=str1;
	int len=str1.length();
	String newstring= " ";
	for(int i=0;i<=len-1;i++)
	{
	int count=1;
for(int j=len-1;j>=0;j++)
{
	if(str1.charAt(j)==str1.charAt(i))
	{
	count++;
	}
}
if(count==1)
{
	newstring=newstring+str1.charAt(i);
}
	}
	System.out.println(newstring);
	}
	public void removeOdd(String str1)
	{
		this.str1=str1;
		String str2=" ";
		for(int i=0;i<str1.length();i++)
		{
			char s=str1.charAt(i);
			if ((i%2)==0)
			{
				s=Character.toUpperCase(s);
				str2=str2+s;
		}
	System.out.println(str2);
	}
	}

}
