package com.cg.stringoperation.ui;

import java.util.Scanner;
import java.time.LocalDate;

import java.time.format.DateTimeFormatter;
public class Product
{
public static void main(String[] args)
{
		System.out.println("Enter puchase date in dd/mm/yyyy");
	Scanner sc=new Scanner(System.in);
	String date=sc.next();
	int m,yrs,temp;
	
	DateTimeFormatter formate= DateTimeFormatter.ofPattern("dd/MM/yyyy");
	LocalDate d= LocalDate.parse(date,formate);
	
	System.out.println("Enter warranty period in mm/yyyy");
	 m=sc.nextInt();
	 yrs=sc.nextInt();
	 temp=yrs*12;
	 m=m+temp;
	 LocalDate exp=d.plusMonths(m);
			 System.out.println("Warranty expires on:" + exp );
	sc.close();
}
}
