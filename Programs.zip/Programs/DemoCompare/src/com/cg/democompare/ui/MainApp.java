package com.cg.democompare.ui;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

public class MainApp {
	public static  void main(String [] args)
	{
		Product proOne=new Product();
		proOne.setProdID(1005);
		proOne.setProdNAME("LG");
		proOne.setProdPRICE(2000);
		
		Product proTwo=new Product();
		proTwo.setProdID(1008);
		proTwo.setProdNAME("Sansui");
		proTwo.setProdPRICE(5000);
		
		Product proThree=new Product();
		proThree.setProdID(1002);
		proThree.setProdNAME("Sony");
		proThree.setProdPRICE(2500);
		
	//	List<Product>mylist=new LinkedList<>();
	//	mylist.add(proOne);
	//	mylist.add(proTwo);
	//	mylist.add(proThree);
		
		Map<Integer,Product> mymap=new  HashMap<>();
		mymap.put(1,proOne);
		mymap.put(2, proTwo);
		mymap.put(3, proThree);
		
		Set set= mymap.entrySet();
		
		
		
		for(Integer keys:mymap.keySet())
		{
			System.out.println( mymap.get(keys).getProdID() );
			System.out.println( mymap.get(keys).getProdNAME());
			System.out.println( mymap.get(keys).getProdPRICE());
		
		}
		
		System.out.println("-------After Sort-------");
		
		Collection<Product> myset=mymap.values();
		
		Set<Product> mylist=new TreeSet<>(myset);
	//	Collections.sort(mylist);
		
		
		
		
	//	Collections.sort((List<Product>) myset);
		
	for(Product prod:mylist)
	{
		System.out.println("Id is : "+ prod.getProdID());		
			System.out.println("Name is :"+ prod.getProdNAME());
	System.out.println("price is:"+ prod.getProdPRICE());
	
	}
	}

}
