package com.cg.studentadmissionhash.dao;


import java.util.Map;

import com.cg.studentadmissionhash.dto.StudentDto;
import com.cg.studentadmissionhash.exception.StudentException;

public interface IStudentColDao {
	
	
	public Map<String,String> getCollegeDetails();
	public Map<Integer,StudentDto>getStudentDetails();
	
	public int addStudentDetails(StudentDto std) ;

}
 
