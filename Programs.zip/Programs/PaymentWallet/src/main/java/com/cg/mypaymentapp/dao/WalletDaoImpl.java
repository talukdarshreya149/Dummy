package com.cg.mypaymentapp.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.mypaymentapp.bean.Customer;

public class WalletDaoImpl implements WalletDao {
	
	private static Map<String, Customer> data; 
	
	static {
		data=new HashMap<String, Customer>();
	}
	
	public String save(Customer customer) {
		// TODO Auto-generated method stub
		data.put(customer.getMobileNo(),customer);
		return customer.getMobileNo();
	}

	public Customer findOne(String mobileNo) {
		// TODO Auto-generated method stub
		return data.get(mobileNo);
	}

	public Map<String, Customer> getDetails() {
		// TODO Auto-generated method stub
		return data;
	}

}

