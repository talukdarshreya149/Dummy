package com.cg.employeedetailslayer.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.employeedetailslayer.dto.Employee;
import com.cg.employeedetailslayer.service.EmployeeServiceImpl;
import com.cg.employeedetailslayer.service.IEmployeeService;

public class EmployeeMain {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee Id");
		
		 int choice=0;
		
				System.out.println("1.Enter to get all the Employee details" + " 2 .Enter employee id to get details" + " 3. Add Employee Details" + " 4. Update salary" );
		
				System.out.println("Enter choice"); 
				choice=sc.nextInt();
		
				IEmployeeService ser=new EmployeeServiceImpl(); 
						
		switch(choice)
		{
		case 1:
		ArrayList <Employee> list=ser.getEmployeeDetails();
		for(Employee emp: list)
		{
			System.out.println("Enter Employee Details");
					
			System.out.println(emp.getEmpId());
			System.out.println(emp.getEmpName());
			System.out.println(emp.getEmpSalary());
		System.out.println(emp.getEmpDesignation());
		
		}
					break;
			
		case 2: 
			System.out.println("Enter Employee Id");
			 int id=sc.nextInt();
			 Employee det=ser.getDetails(id);
			if(det==null) {
				System.out.println("Not Found");
			}
			else
			{
				System.out.println(det.getEmpId());
				System.out.println(det.getEmpName());
				System.out.println(det.getEmpSalary());
				System.out.println(det.getEmpDesignation());
			}
		break;
		
		case 3:
			System.out.println("Enter Employee Id");
		int eid=sc.nextInt();
		System.out.println("Enter Employee Name");
		String ename=sc.next();
		System.out.println("Enter Salary");
		double esal=sc.nextDouble();
		System.out.println("Enter Designation");
		String edesign=sc.next();
		
		Employee empl=new Employee();
		
		empl.setEmpId(eid);
		empl.setEmpName(ename);
		empl.setEmpSalary(esal);
		empl.setEmpDesignation(edesign);
		
		ser.addEmployee(empl);
		
		break;
		
		case 4:
		
			System.out.println("Enter Employee Id to update salary");
			int id1=sc.nextInt();
			System.out.println("Enter salary to update");
		double sal1=sc.nextDouble();
		ser.updatesalary(id1, sal1);
		break;
		
		default:
			System.out.println("Invalid Choice....Try Again");
			
		}
		sc.close();
	}
}
