package com.cg.labelevenfour;

public class Employee {
private int empId;
private String name;

public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String viewDetails(int id,String name) {
	return "Employee ID:" + id + "\n" + "Employee Name:" + name;
}
}
