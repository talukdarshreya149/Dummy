package com.cg.studentadmissionhash.service;

import java.time.LocalDate;

import com.cg.studentadmissionhash.dto.StudentDto;
import com.cg.studentadmissionhash.exception.StudentException;

public interface IStudentColService {

	public int addStudentDetails(StudentDto std);
	public  StudentDto viewStudentDetails(int studentId) ;
	
	public boolean validateName(String name, int age, String date, String emailid, String phone) throws StudentException;
}
