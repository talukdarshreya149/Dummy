package com.cg.poly.service;

import com.cg.poly.service.Aone;

import com.cg.poly.service.Bone;
	public class MyMain 
	{
		public static void main(String [] args)
		{
			Aone temp= new Bone(); // Runtime poly
		 ((Bone)temp).getData();
			
		
		}


}
