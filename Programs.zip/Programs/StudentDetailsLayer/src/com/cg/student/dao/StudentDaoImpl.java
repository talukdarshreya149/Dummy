package com.cg.student.dao;

import java.util.HashSet;

import com.cg.student.dto.StudentDto;

public class StudentDaoImpl implements IStudentDao {
	
	private static HashSet<StudentDto> studentdetails=null;
	
 static {

	studentdetails=new HashSet<>();
	
	}
	@Override
	public StudentDto searchStudent(int id) {
		// TODO Auto-generated method stub
		StudentDto search=null;
		for(StudentDto dto: studentdetails)
		{
			if(dto.getStId()==id) {
				search=dto;
			}
		}
		return search;
	}

	@Override
	public void deleteStudent(int did) {
		// TODO Auto-generated method stub
		for(StudentDto stud :studentdetails) {
			if(stud.getStId()==did)
		{
			studentdetails.remove(stud);
			break;
		}
	}
		}
	

	@Override
	public HashSet<StudentDto> viewStudentDetails() {
		// TODO Auto-generated method stub
		return studentdetails;
	}

	@Override
	public int addStudentDao(StudentDto studentdto) {
		// TODO Auto-generated method stub
		int generatedId=(int)(Math.random()*10000);
		studentdto.setStId(generatedId);
		studentdetails.add(studentdto);
		return generatedId;
		
	}

	
}
