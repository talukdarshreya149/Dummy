package com.cg.service;

import com.cg.dao.ILoginDao;
import com.cg.dao.LoginDaoImpl;

public class LoginServiceImpl implements ILoginsService {
private ILoginDao dao=null;
 public LoginServiceImpl() {
	// TODO Auto-generated constructor stub
	dao=new LoginDaoImpl();
}
	@Override
	public boolean login(String username, String password) {
		// TODO Auto-generated method stub
		boolean result =false;
		if(username.trim().length()>4&&password.trim().length()>4)
{         result=dao.login(username,password);  
	}


return result;

	}

}