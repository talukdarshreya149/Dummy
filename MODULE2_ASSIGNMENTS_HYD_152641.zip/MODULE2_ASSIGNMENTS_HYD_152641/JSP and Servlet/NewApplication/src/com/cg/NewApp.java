package com.cg;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/user.do")
public class NewApp extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public NewApp() {
    	 super();
    	System.out.println("in ");
       
        // TODO Auto-generated constructor stub
    }
PrintWriter out=null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		out=response.getWriter();
		String n=request.getParameter("name").trim();
		String c=request.getParameter("city").trim();
		String m=request.getParameter("mobile").trim();
		String u=request.getParameter("username").trim();
		String e=request.getParameter("email").trim();
		String g=request.getParameter("gender").trim();
		String courseList[]=request.getParameterValues("course");
		
		out.println("<h1>name : "+n+"</h1");
		out.println("<h1>city : "+c+"</h1");
		out.println("<h1>mobile : "+m+"</h1");
		out.println("<h1>username : "+u+"</h1");
		out.println("<h1>email : "+e+"</h1");
		out.println("<h1>gender : "+g+"</h1");
		
		for(String course:courseList) {
			out.println(course + " , ");
		}
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		doGet(request, response);
	}

}
