package com.cg.demo8.ui;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Scanner;
public class MyMainApplication {

	public static void main(String[] args) throws EmployeeException
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter age");
	int age=sc.nextInt();
	Employe emp=new Employe();
	try {
		
	
	emp.setEmpAge(age);
	} catch (EmployeeException e) {
		System.out.println(e.getMessage());
	}
}
}
