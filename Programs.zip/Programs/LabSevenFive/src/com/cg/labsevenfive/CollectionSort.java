package com.cg.labsevenfive;


import java.util.ArrayList;
import java.util.Collections;

public class CollectionSort {
	public static void main(String[] args)
	{
		ArrayList<String> list1=new ArrayList<String>();
		
		list1.add("AAA REYA");
		list1.add("PIA");
		list1.add("SHREYAAAAA");
		list1.add("YYYYAaaa");
		Collections.sort(list1);
		
		for (String st : list1) {
			System.out.println(st);
		}
		
	}

}
