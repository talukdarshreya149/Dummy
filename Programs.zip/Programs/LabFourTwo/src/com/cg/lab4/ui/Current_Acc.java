package com.cg.lab4.ui;

public class Current_Acc extends Account
{
 double over_draftlimit = 50000;
double balance;

public boolean withDraw( double b_withdrawn)
{
	this.balance=balance;
	if(b_withdrawn>over_draftlimit)
{
System.out.println("Cannot withdraw");	
return true;
}
	else
	{
		System.out.println("You can withdraw");
		balance=balance-b_withdrawn;
		return false;
	}
}
}
