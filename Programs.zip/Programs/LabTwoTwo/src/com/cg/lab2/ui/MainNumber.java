package com.cg.lab2.ui;

public class MainNumber 
{	
	public static void main(String[] args)
	{
		Number num= new Number();

		int num1= Integer.parseInt(args[0]);
		
		int Result= num.check_num(num1);
		System.out.println("The number is " +  Result);
		
	}

		
	}

