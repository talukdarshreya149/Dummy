package com.cg.lab6.ui;


public class Employee {
	String firstName;
	String lastName;
		long phone;
	
	
	public Employee()
	{
	System.out.println("Details of person");
	
	}
	public Employee(String firstName, String lastName, char gender,long phone)
	{
		this.firstName=firstName;
		this.lastName=lastName;
		
        this.phone=phone;
		
}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) throws NullPointerException
	            {
	
				this.firstName = firstName;
				}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
			
	}


