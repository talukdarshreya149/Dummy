package com.cg.demoten.dao;

import java.util.LinkedList;
import java.util.List;

import com.cg.demoten.dto.Product;

public class ProductDaoImpl implements IProductDao{


	List<Product>mylist=new LinkedList<>();
	@Override
	public void addProductDao(Product pro) {
		// TODO Auto-generated method stub
		mylist.add(pro);
	}
	@Override
	public List<Product> showAllProductDao() {
		// TODO Auto-generated method stub
		return mylist;
	}
	@Override
	public Product searchProductDao(int prodid) {
		// TODO Auto-generated method stub
		Product psearch=null;
		for(Product product: mylist)
		{
			if(product.getProdId()==prodid) {
				psearch=product;
			break;
			}
		}
		return psearch;
	}
	@Override
	public void removeProductDao(int prorid) {
		// TODO Auto-generated method stub
				for(Product prod :mylist) {
			if(prod.getProdId()==prorid)
		{
			mylist.remove(prorid);
			break;
		}
	}
	
		// TODO Auto-generated method stub
		
	}

}
