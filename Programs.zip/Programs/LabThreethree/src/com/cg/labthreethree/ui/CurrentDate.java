package com.cg.labthreethree.ui;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class CurrentDate {
	public static void main(String[] args)

	{
			DateTimeFormatter formate= DateTimeFormatter.ofPattern("dd/MM/yyyy");
			 Scanner sc= new Scanner(System.in);
			 
			 System.out.println("Enter the Date in dd/mm/yyyy");
				String date =sc.next();
			LocalDate today=LocalDate.now();
			LocalDate date1=LocalDate.parse(date,formate);
		
		   Period period= date1.until(today);
		   System.out.println("Days:" + period.getDays());
		   System.out.println("Months:" + period.getMonths());
		   System.out.println("Years:" + period.getYears());
	    sc.close();
	}

}
