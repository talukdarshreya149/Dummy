package com.cg.demoabstact.ui;

import java.util.Scanner;

import com.cg.demosix.dto.Employee;
import com.cg.demosix.dto.Project;

public class Mainemp 
{
	public static void main(String [] args)

	{
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter employee id");
		int eid=sc.nextInt();
		System.out.println("Enter employee name");
		String ename=sc.next();
		System.out.println("Enter employee salary");
		int esal=sc.nextInt();
		System.out.println("enter project id");
	int pid=sc.nextInt();
	System.out.println("enter project name");
	String pname=sc.next();
	
	Project proj=new Project();
	proj.setProjId(pid);
	proj.setProjName(pname);
	
	Employee empOne= new Employee();
	empOne.setEmpid(eid);
	empOne.setEmpName(ename);
	empOne.setEmpSalary(esal);
		empOne.setProj(proj);
		
		System.out.println("Display All data......");	
	System.out.println("Employee Id is "+ empOne.getEmpid() );	
	
	System.out.println("Employee Name is " +  empOne.getEmpName());
		
			System.out.println("Employee Salary is " +  empOne.getEmpSalary());
		
					System.out.println("Employee project Id " +  empOne.getProj().getProjId());
							
							System.out.println("Employee Project name " + empOne.getProj().getProjName());
	
	sc.close();
	}
}
