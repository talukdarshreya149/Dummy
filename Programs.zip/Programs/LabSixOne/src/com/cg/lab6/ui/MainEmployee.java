package com.cg.lab6.ui;

import java.util.Scanner;

public class MainEmployee extends Exception{
	public static void main(String[] args)
	{
		Employee emp= new Employee();

		String st1=new String();
		String st2=new String();
		 Scanner sc=new Scanner(System.in);
		
		 System.out.println("Enter the First Name");
				 st1=sc.nextLine();
		if(st1.equals(null) ||st1.isEmpty())
		{
			try {
			throw new NullPointerException("Cannot take empty string");
		}
			catch(NullPointerException e)	
			{
				System.out.println(e.getMessage());
			}
				 System.out.println("Enter the Last Name");
				 st2=sc.nextLine();
		 if(st2.equals(null)||st2.isEmpty())
		 
		 {
			 try {
				 throw new NullPointerException("Cannot take empty string. Enter some value");
			 }
		 catch(NullPointerException e)
			 {
			 System.out.println(e.getMessage());
			 }
		 }
		
		
		
emp.setFirstName("Shreya");
emp.setLastName("Talukdar");

emp.setPhone(456695345);
System.out.println(emp.getFirstName());
System.out.println(emp.getLastName());

System.out.println(emp.getPhone());

		
	}
}
}

