package com.cg.demotwo.ui;

public class MyEmployee
{
public static void main(String[] args)
{
	Employee emp= new Employee();
	emp.printAllDetails();
}
}
