package com.cg.tms.exception;

public class TicketException extends Exception {

	public TicketException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
	public TicketException() {
		// TODO Auto-generated constructor stub
	}

}
