package com.cg.lab4.ui;

public class MainAccount 
{
public static void main(String [] args)
{
	
Saving_Acc a1= new Saving_Acc();
a1.withdraw(12000);
Current_Acc a2=new Current_Acc();
a2.withDraw(500000);
}
}