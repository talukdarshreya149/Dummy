package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public class Service extends Employee implements Employee_Insurance 
{

	public String checkScheme( String empDesign, double empSal)
	{
		this.empSal=empSal;
		this.empDesign=empDesign;
		System.out.println(empSal);
		System.out.println(empDesign);
		
		if((empSal>=5000 && empSal<20000.0)&&(empDesign.equalsIgnoreCase("SystemAssociate")))
				{
			return "Scheme C";
		
				}
		else if((empSal>=20000 && empSal<40000)&&(empDesign.equalsIgnoreCase("Programmer")))
		{
			return "Scheme B";
		}
		else if((empSal>=40000)&&(empDesign.equalsIgnoreCase("Manager")))
		{
			return "Scheme A";
				}
		else if((empSal<5000)&&(empDesign.equalsIgnoreCase("clerk")))
		{
			return "No Scheme";
		}
		
		else
		{
			return null;
			
		}
	}



	}

	