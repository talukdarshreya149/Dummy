package com.cg.jenkins.JenkinsMavenTest;

import static org.junit.Assert.*;

import org.junit.Test;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GithubTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}


@Given("^I navigate to \"([^\"]*)\"$")
public void i_navigate_to(String arg1) throws Throwable {
    
}

@When("^I click on \"([^\"]*)\" button without entering username$")
public void i_click_on_button_without_entering_username(String arg1) throws Throwable {
    
}

@Then("^I should get a message as username cant be blank$")
public void i_should_get_a_message_as_username_cant_be_blank() throws Throwable {
   
}

@When("^I click on \"([^\"]*)\" button without entering email$")
public void i_click_on_button_without_entering_email(String arg1) throws Throwable {
}

@Then("^I should get a message as email cant be blank$")
public void i_should_get_a_message_as_email_cant_be_blank() throws Throwable {

}

@When("^I click on \"([^\"]*)\" button without entering password$")
public void i_click_on_button_without_entering_password(String arg1) throws Throwable {
    
}

@Then("^I should get a message as password cant be blank$")
public void i_should_get_a_message_as_password_cant_be_blank() throws Throwable {
  
}

@When("^I enter a password of less than (\\d+) characters$")
public void i_enter_a_password_of_less_than_characters(int arg1) throws Throwable {
    
}

@Then("^I should get a message that password cannot be less than (\\d+) characters$")
public void i_should_get_a_message_that_password_cannot_be_less_than_characters(int arg1) throws Throwable {
   
}

@When("^I enter a password which do not start with Capital letter or do not contain a number or a special character$")
public void i_enter_a_password_which_do_not_start_with_Capital_letter_or_do_not_contain_a_number_or_a_special_character() throws Throwable {
  
}

@Then("^I should get a message that password is invalid$")
public void i_should_get_a_message_that_password_is_invalid() throws Throwable {
    
}

@When("^After successfully filling all the blanks$")
public void after_successfully_filling_all_the_blanks() throws Throwable {
    
}

@When("^I click on \"([^\"]*)\"$")
public void i_click_on(String arg1) throws Throwable {
    
}

@Then("^It goes to next page$")
public void it_goes_to_next_page() throws Throwable {
    
}


}
