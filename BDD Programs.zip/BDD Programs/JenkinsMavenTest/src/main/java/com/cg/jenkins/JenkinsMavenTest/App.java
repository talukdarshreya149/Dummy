package com.cg.jenkins.JenkinsMavenTest;


public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Bye Bye" );
    }
}
