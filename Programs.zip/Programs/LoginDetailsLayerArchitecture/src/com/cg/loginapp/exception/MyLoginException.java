package com.cg.loginapp.exception;

public class MyLoginException extends Exception {

	public MyLoginException() {
		// TODO Auto-generated constructor stub
	}

	public MyLoginException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

	

}
