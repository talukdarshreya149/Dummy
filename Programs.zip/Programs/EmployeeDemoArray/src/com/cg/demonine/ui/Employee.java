package com.cg.demonine.ui;

public class Employee 
{
private String empName;
private int empId;
private int empAge;
public String getEmpName() {
	return empName;
}
public void setEmpName(String empName) {
	this.empName = empName;
}
public int getEmpId() {
	return empId;
}
public void setEmpId(int empId) {
	this.empId = empId;
}
public int getEmpAge() {
	return empAge;
}
public void setEmpAge(int empAge) {
	this.empAge = empAge;
}

	// TODO Auto-generated method stub
	
}


