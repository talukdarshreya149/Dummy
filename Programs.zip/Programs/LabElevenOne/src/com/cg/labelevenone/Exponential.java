package com.cg.labelevenone;

public class Exponential {
	public static void main(String[] args) {

		IExponential l=(num1,num2) -> Math.pow(num1, num2);	
		double d=l.power(2, 3);
		System.out.println(d);
		}

}
