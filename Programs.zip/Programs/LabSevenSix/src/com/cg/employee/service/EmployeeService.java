package com.cg.employee.service;

import com.cg.employee.dao.EmployeeDao;
import com.cg.employee.dao.IEmployeeDao;
import com.cg.employee.dto.Employee;

public class EmployeeService implements IEmployeeService {
private static IEmployeeDao dao= null;
static{
	dao= new EmployeeDao();
}
	@Override
	public void addDetails(Employee emp) throws Exception {
		dao.addDetailsDao(emp);
	}
	@Override
	public Employee getEmployeeDetails(String scheme1) throws Exception {
	
		return dao.getEmployeeDetailsDao(scheme1);
	}

}
