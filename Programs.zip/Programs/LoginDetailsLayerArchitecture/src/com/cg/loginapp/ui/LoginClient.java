package com.cg.loginapp.ui;

import java.util.Scanner;

import com.cg.loginapp.dto.UserBean;
import com.cg.loginapp.exception.MyLoginException;
import com.cg.loginapp.service.ILoginService;
import com.cg.loginapp.service.LoginServiceImpl;

public class LoginClient {
	public static void main(String[] args) throws MyLoginException{
Scanner	 scanner = new Scanner(System.in);
System.out.println("Enter Username");
String username=scanner.next();
System.out.println("Enter Password");
String password=scanner.next();

ILoginService service= new LoginServiceImpl();
UserBean userBean=new UserBean();
userBean.setUserName(username);
userBean.setPassword(password);

service.validateLogin(userBean);
	
boolean result=service.validateLogin(userBean);
if(result)
{
	boolean output=service.verifyLogin(userBean);

if(output) {
System.out.println("Welcome " +  username);	
}else {
	
	System.out.println("Invalid Login .Try Again");
}

} else {
	System.out.println("invalid Login.Try Again");
}
}

}
