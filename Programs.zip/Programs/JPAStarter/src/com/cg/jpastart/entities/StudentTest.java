package com.cg.jpastart.entities;

public class StudentTest {

}
