package com.cg.spring.boot.dto;

public class Product {

	private String prodid;
	private String prodname;
	private String prodmodel;
	private double prodprice;
	
	
	public String getProdid() {
		return prodid;
	}
	public void setProdid(String prodid) {
		this.prodid = prodid;
	}
	public String getProdname() {
		return prodname;
	}
	public void setProdname(String prodname) {
		this.prodname = prodname;
	}
	public String getProdmodel() {
		return prodmodel;
	}
	public void setProdmodel(String prodmodel) {
		this.prodmodel = prodmodel;
	}
	public double getProdprice() {
		return prodprice;
	}
	public void setProdprice(double prodprice) {
		this.prodprice = prodprice;
	}
	
	
	
}
