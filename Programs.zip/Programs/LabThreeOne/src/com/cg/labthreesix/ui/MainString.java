package com.cg.labthreesix.ui;

import java.util.Scanner;


public class MainString {
	
public static void main(String[] args)
{
		StringOperation st= new StringOperation()	; 
		Scanner sc=new Scanner(System.in);
		String str=new String();

		System.out.println("Enter choice of string");
		str=sc.next();
		System.out.println(" ** Menu **");
	System.out.println("1. To add a string to itself \n" + "2. To replace odd places with # \n" + "3. To remove duplicate characters fron string \n"+"4. to odd characters to Uppercase" );

	int ch=sc.nextInt();

	switch(ch)
	{
	case 1: st.addString(str);
	break;
	case 2: st.hashOdd(str);
	break;
	case 3: st.duplicateChar(str);
	break;
	case 4: st.removeOdd(str);
	break;
	default : System.out.println("You have entered wrong choice");
	}
		
		sc.close();
		}
	}
