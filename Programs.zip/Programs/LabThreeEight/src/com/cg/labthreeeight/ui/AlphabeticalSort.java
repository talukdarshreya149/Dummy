package com.cg.labthreeeight.ui;

import java.util.Scanner;

public class AlphabeticalSort {
	
	public static void main(String args[])
	{
		int mid,n;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the no.of elements");
		n=sc.nextInt();
		
		String st[] = new String[50];
		System.out.println("Enter string value");
		for(int i=0;i<n;i++)
		{
			st[i]=sc.nextLine();
		}
		
		for(int i=0;i<n-1;i++)
		{
			for(int j=i+1;j<n-1;j++)
			{
				if(st[i].compareTo(st[j])>0)
				{
					String temp=st[i];
					st[i]=st[j];
					st[j]=temp;
					
				}
			}
		}
	mid=(n/2)+1;
	for(int i=0;i<mid;i++)
	{
		st[i]=st[i].toUpperCase();
	}
		for(int i=mid+1;i<n;i++)
		{	
			st[i]=st[i].toLowerCase();
		}
		
	System.out.println("Final Array is : :");
	for(int i=0;i<n;i++)
		{
		System.out.println(st[i] + " ");
		
		}
	sc.close();
	}
}
