package com.cg.mypaymentapp.controller;

import java.math.BigDecimal;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.cg.mypaymentapp.bean.Customer;

import com.cg.mypaymentapp.service.WalletService;

@RestController
public class PaymentController {

	@Autowired
	private WalletService service;
	

	@RequestMapping(value="/add", method=RequestMethod.POST)
	public void addProduct(@RequestBody Customer customer) {
		service.createAccount(customer);
	}
	
	@RequestMapping(value="/show/{mobile}")
	public Optional<Customer> showBalance(@PathVariable String mobile){
		return service.showBalance(mobile);
				
	}
	
	@RequestMapping(value="/deposit/{mobile}/{amt}", method=RequestMethod.PUT)
	public Customer deposit( @PathVariable String mobile, @PathVariable BigDecimal amt) {
		return service.depositAmount(mobile, amt);
		
	}
	
	@RequestMapping(value="/withdraw/{mobile}/{amt}", method=RequestMethod.PUT)
	public Customer withdraw( @PathVariable String mobile, @PathVariable BigDecimal amt) {
		return service.withdrawAmount(mobile, amt);
		
	}
	
	@RequestMapping(value="/fund/{mobile1}/{mobile2}/{amt}", method=RequestMethod.PUT)
	public Customer fundTransfer( @PathVariable String mobile1,@PathVariable String mobile2, @PathVariable BigDecimal amt) {
		return service.fundTransfer(mobile1, mobile2, amt);
		
	}
	
	@RequestMapping("/transaction/{mobile}")
		public String printTransaction( @PathVariable String mobile) {
			return service.printTransaction(mobile);		
		
	}
}
