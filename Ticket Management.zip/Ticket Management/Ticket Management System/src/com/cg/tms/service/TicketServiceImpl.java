package com.cg.tms.service;

import java.util.List;

import com.cg.tms.dao.TicketDAO;
import com.cg.tms.dao.TicketDAOImpl;
import com.cg.tms.dto.TicketBean;
import com.cg.tms.dto.TicketCategory;
import com.cg.tms.exception.ITicketException;
import com.cg.tms.exception.TicketException;

public class TicketServiceImpl implements TicketService {

	TicketDAO dao = new TicketDAOImpl();

	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) {
		ticketBean.setTicketStatus("New");
		int ticketNo = (int) (Math.random() * 10000 + 1);
		ticketBean.setTicketNo(String.valueOf(ticketNo));
		return dao.raiseNewTicket(ticketBean);
	}

	@Override
	public List<TicketCategory> listTicketCategory() {
		return dao.listTicketCategory();
	}
	
	public boolean validate(String name) throws TicketException {
		// TODO Auto-generated method stub
		boolean result=false;
		if(name.trim().matches("^[a-zA-Z]+$")){
			result=true;
		}else
		{
			throw new TicketException(ITicketException.ERROR1);
		}
		return result;
	}
		
	
		}


