package com.cg.democompare.ui;

public class A {
 void getData()
{
	System.out.println("print A...");
}

}
