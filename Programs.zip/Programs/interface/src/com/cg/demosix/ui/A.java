package com.cg.demosix.ui;

import com.cg.demosix.service.iEmployeeService;

public interface A extends iEmployeeService
{

}
