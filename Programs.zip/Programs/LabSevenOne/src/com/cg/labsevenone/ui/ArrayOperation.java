package com.cg.labsevenone.ui;

import java.util.Arrays;
import java.util.Scanner;

public class ArrayOperation {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter no. of elements");
		int size = sc.nextInt();

		int number[] = new int[size];

		System.out.println("Enter numbers in array");
		for (int i = 0; i < size; i++) {
			number[i] = sc.nextInt();
		}

		int finalnum[] = getSorted(number);
		System.out.println("Final array is");
		for (int i : finalnum) {
			System.out.println(i);
		}
	}

	public static int[] getSorted(int number[]) {
		for (int i = 0; i < number.length; i++) {
			StringBuilder newArr = new StringBuilder(String.valueOf(number[i]));
			newArr.reverse();
			number[i] = Integer.parseInt(newArr.toString());
		}
		Arrays.sort(number);
		return number;
	}

}
