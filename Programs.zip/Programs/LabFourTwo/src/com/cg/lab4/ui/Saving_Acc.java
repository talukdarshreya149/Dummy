package com.cg.lab4.ui;

public class Saving_Acc extends Account {
double min_balance =3000;
double balance;
double currbal;

public double withdraw(double b_withdraw)
{
	double x;
	this.balance = balance;
	x=balance-b_withdraw;
	if(x>min_balance)
{
		System.out.println("Cannot Withdraw");
}
else
{
	System.out.println("You can withdraw");
}
return x;
}
}
