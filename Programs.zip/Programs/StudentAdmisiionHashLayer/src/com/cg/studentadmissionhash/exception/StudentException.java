package com.cg.studentadmissionhash.exception;

public class StudentException extends Exception {
	
	public StudentException(){
	System.out.println("Invalid details");	
	}
public StudentException(String message) {
	super(message);
	
}
}
