package service;

import java.util.List;

import dao.TicketDAO;
import dao.TicketDAOImpl;
import dto.TicketBean;
import dto.TicketCategory;

public class TicketServiceImpl implements TicketService {

	TicketDAO dao = new TicketDAOImpl();

	@Override
	public boolean raiseNewTicket(TicketBean ticketBean) {
		ticketBean.setTicketStatus("New");
		int ticketNo = (int) (Math.random() * 50 + 1);
		ticketBean.setTicketNo(String.valueOf(ticketNo));
		return dao.raiseNewTicket(ticketBean);
	}

	@Override
	public List<TicketCategory> listTicketCategory() {
		return dao.listTicketCategory();
	}

}
