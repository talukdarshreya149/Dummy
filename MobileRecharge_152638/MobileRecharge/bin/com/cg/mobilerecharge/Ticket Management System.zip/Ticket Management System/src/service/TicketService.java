package service;

import java.util.List;

import dto.TicketBean;
import dto.TicketCategory;

public interface TicketService {
	public boolean raiseNewTicket(TicketBean ticketBean);
	public List<TicketCategory>listTicketCategory();

}
