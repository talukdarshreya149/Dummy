package com.cg.student.service;

import java.util.HashSet;

import com.cg.student.dto.StudentDto;
import com.cg.student.exception.MyException;

public interface IStudentService {
	
	
 public int addStudent(StudentDto studentdto);
 public HashSet<StudentDto> viewStudentDetails();
public StudentDto searchStudent(int id); 
public void deleteStudent(int did);
public boolean validate(String name, String dob) throws MyException;


}
