package com.cg.labtwoone.ui;

public class PersonOne
{
String first_name= " Shreya";
String last_name= " Talukdar";
char gender= 'F';
int age= 21;
int weight=50;

public PersonOne()
{
	System.out.println("Details of a person : ");
}
public PersonOne(String first_name, String last_name, char gender, int age, int weight)
{
	this.first_name=first_name;
	this.last_name=last_name;
	this.gender=gender;
	this.age=age;
	this.weight=weight;
}
public void printAllDetails()
{
	System.out.println("First Name :" + first_name);
	System.out.println("Last Name :" + last_name);
	System.out.println("Gender :" + gender);
	System.out.println("Age :" + age);
	System.out.println("Weight :" + weight);
	
}
}
