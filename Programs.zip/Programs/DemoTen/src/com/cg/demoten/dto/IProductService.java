package com.cg.demoten.dto;

import java.util.List;

public interface IProductService {

	public void addProduct(Product pro);
	
	public List<Product>showAllProduct();
	public Product searchProduct(int prodid);
	public void removeProduct(int prorid);
	
	
}
