package com.cg.loginapp.service;

import com.cg.loginapp.dto.UserBean;
import com.cg.loginapp.exception.MyLoginException;

public interface ILoginService {
	public boolean validateLogin(UserBean userBean);
	 public boolean verifyLogin(UserBean userBean) throws MyLoginException;
	 

}
