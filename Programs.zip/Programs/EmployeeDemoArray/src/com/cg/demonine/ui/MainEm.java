package com.cg.demonine.ui;

public class MainEm {
	public static void main(String [] args)
	{
		Employee emp[] =new Employee[3];
		
		emp[0]=new Employee();
		emp[0].setEmpId(100);
	    emp[0].setEmpName("Shreya");
	       emp[0].setEmpAge(21);
	
	
	       emp[1]=new Employee();
			emp[1].setEmpId(101);
		    emp[1].setEmpName("Reya");
		       emp[1].setEmpAge(25);
		
		       emp[2]=new Employee();
				emp[2].setEmpId(103);
			    emp[2].setEmpName("Anya");
			       emp[2].setEmpAge(24);
			
	for(Employee emp1: emp)
	{
		System.out.println(emp1.getEmpId());
		System.out.println(emp1.getEmpName());
		System.out.println(emp1.getEmpAge());
	}
	
	}

}
