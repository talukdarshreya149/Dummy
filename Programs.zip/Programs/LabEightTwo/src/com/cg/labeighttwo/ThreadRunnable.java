package com.cg.labeighttwo;

public class ThreadRunnable implements Runnable {
public static void main(String[] args) {
		
	ThreadRunnable obj=new ThreadRunnable();
		Thread t=new Thread(obj);
		t.start();
	}
	
	@Override
	public void run() {
		
		
		while(true) {
		System.out.println(System.currentTimeMillis());
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
	}
}
