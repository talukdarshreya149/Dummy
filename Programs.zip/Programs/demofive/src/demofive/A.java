package demofive.service;

public class A {

}
