package com.cg.jpaproduct.service;

import java.util.List;

import com.cg.jpaproduct.entities.Product;


public interface IProductService {

	public abstract void addProduct(Product pro);
	
	public abstract List<Product>showAllProduct();
	public abstract Product searchProduct(int prodid);
	public abstract void removeProduct(int prorid);
	
	
}
