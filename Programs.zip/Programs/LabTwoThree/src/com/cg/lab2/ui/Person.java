package com.cg.lab2.ui;

public class Person 
{
	String firstName;
	String lastName;
	char gender;
	long phone;
	
	
	public Person()
	{
	System.out.println("Details of person");
	
	}
	public Person(String firstName, String lastName, char gender,long phone)
	{
		this.firstName=firstName;
		this.lastName=lastName;
		this.gender=gender;
        this.phone=phone;
		
}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public char getGender()
	{
		return gender;
	}
	public void setGender(char gender)
	{
		this.gender = gender;
		}
	

		
	}

