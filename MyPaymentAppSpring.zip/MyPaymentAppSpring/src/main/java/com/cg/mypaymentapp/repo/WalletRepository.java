package com.cg.mypaymentapp.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.mypaymentapp.bean.Customer;

@Repository("WalletRepo")
public interface WalletRepository extends CrudRepository<Customer, String> {

}
