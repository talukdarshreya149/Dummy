package com.cg.demoseven.service;

public class Outer {

	public static class Inner{
		public void getData()
		{
		System.out.println(" In Innner class..." );
		}
	}

	public void showData() {
		// TODO Auto-generated method stub
		System.out.println("In Outer class....");
	}
}
