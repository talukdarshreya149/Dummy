package com.cg.mra.userbean;

// package containing all the beans

public class Account {

	private String mobileNo;
	private String accountType;
	private String customerName;
	private double accountBalance;
	
	private double rechargeAmount;
	//------------------------    <Mobile_recharge> Application --------------------------
		/*******************************************************************************************************
		 - Method Name	        :	<getMobileNo>
		 - Input Parameters	:	<MobileNo, customerName,accountBalance,rechargeBalance> <string,double>
		 - Return Type		:	<variable name> <data type>
		 - Throws		:  	<Application_name>Exception
		 - Author		:	<Your_name>
		 - Creation Date	:	dd/MM/yyyy
		 - Description		:	write description of the method in few lines
		 ********************************************************************************************************/
	
	// getter,setter of all the beans
	
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public double getRechargeAmount() {
		return rechargeAmount;
	}
	public void setRechargeAmount(double rechargeAmount) {
		this.rechargeAmount = rechargeAmount;
	}
	
}
