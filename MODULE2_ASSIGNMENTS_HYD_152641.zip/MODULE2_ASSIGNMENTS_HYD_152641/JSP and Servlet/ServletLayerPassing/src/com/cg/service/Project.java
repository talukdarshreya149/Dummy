package com.cg.service;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Project
 */
@WebServlet("/user.do")
public class Project extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Project() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
    PrintWriter out=null;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		out=response.getWriter();
		String n=request.getParameter("txtName").trim();
		String c=request.getParameter("txtCity").trim();
		String m=request.getParameter("txtMobile").trim();
		String u=request.getParameter("txtUsername").trim();
    	String e=request.getParameter("txtEmail").trim();
   		String g=request.getParameter("rdGender").trim();
		//String courseList[]=request.getParameterValues("Course");
   		
		/*out.println("<h1> name : " + n+ "</h1>");
		out.println("<h1> city : " + c+ "</h1>");
		out.println("<h1> mobile : " + m+ "</h1>");
		out.println("<h1> username : " + u+ "</h1>");
		out.println("<h1> email : " + e+ "</h1>");
		out.println("<h1> gender : " + g+ "</h1>");
		
		for(String course : courseList) {
			out.println(course + " ,");
		}*/
		
		request.setAttribute("txtName",n);
		request.setAttribute("txtCity",c);
		request.setAttribute("txtMobile",m);
		request.setAttribute("txtUsername",u);
		request.setAttribute("txtEmail",e);
		request.setAttribute("rdGender",g);
		
		RequestDispatcher rd=request.getRequestDispatcher("ServletView");
		
		rd.forward(request,response);
		
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
