package com.cg.thread;

public class Client {
public static  void main(String[] args)
{
	Thread.currentThread().setPriority(-1);
	Display disp=new Display();
	MyThread mythread1=new MyThread(disp,"Virat");
	MyThread mythread2=new MyThread(disp, "Dhoni");
	mythread1.start();
	mythread1.notify();
	mythread2.start();
}
}
