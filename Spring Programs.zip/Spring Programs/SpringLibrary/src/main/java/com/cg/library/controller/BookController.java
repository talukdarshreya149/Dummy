package com.cg.library.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.library.beans.Book;
import com.cg.library.service.BookService;

@RestController
public class BookController {

	@Autowired
	private BookService service;
	
	@RequestMapping(value="/add", method=RequestMethod.POST)
	public void addBook( @RequestBody Book b ){
		service.addBook(b);
	}
	
	@RequestMapping(value="/update/{id}", method=RequestMethod.PUT)
	public void updateBook(@RequestBody Book b ,@PathVariable int id) {
		service.updateBook(b, id);
	}
	
	 @RequestMapping(value="/delete/{id}", method=RequestMethod.DELETE)
	public void deleteBookById(@PathVariable int id)
	{
		service.deleteBook(id);
		}
	
	@RequestMapping("/show")
	public List<Book> getAllbooks(){
		return service.getAllBooks();
		}
	
	@RequestMapping("/products/{id}")
	public Optional<Book> getBookById(@PathVariable int id){
		return service.getBookById(id);
	  }

}
