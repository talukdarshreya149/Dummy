package com.cg.Test;

import static org.junit.Assert.*;

import java.util.List;

import org.junit.After;

import org.junit.Before;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class ImageCountTest {

	WebDriver driver;
	@Before
	public  void setUpBeforeClass() throws Exception {
		System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe" );
		  driver=new ChromeDriver();
	}

	@After
	public  void tearDownAfterClass() throws Exception {
		driver.quit();
	}

	@Test
	public void test() {
		 driver.get("https://www.amazon.com/");
	        List<WebElement> listwebelement = driver.findElements(By.tagName("img"));
	        System.out.println("No. of images" + listwebelement.size());
	              for (WebElement name : listwebelement) {
	            	  System.out.println("Name of images" + name.getAttribute("alt"));
	              }
	}

}
