package com.cg.mra.service;

import com.cg.mra.dao.AccountDao;
import com.cg.mra.dao.AccountDaoImpl;
import com.cg.mra.exception.AccountException;
import com.cg.mra.exception.AccountExceptionMessages;
import com.cg.mra.userbean.Account;

public class AccountServiceImpl implements AccountService {

	AccountDao accountdao=new AccountDaoImpl();
	//------------------------    <Mobile_recharge> Application --------------------------
		/*******************************************************************************************************
		 - Method Name	        :	<getAccountDetails>
		 - Input Parameters	:	<mobileNo,rechargeAccount)> <String,account>
		 - Return Type		:	<variable name> <data type>
		 - Throws		:  	<AccountException>Exception
		 - Author		:	<Shreya_152641>
		 - Creation Date	:	11/07/2018
		 - Description		:	write description of the method in few lines
		 ********************************************************************************************************/
	
	
	@Override
	public Account getAccountDetails(String mobileNo) {
		// TODO Auto-generated method stub
		
		return accountdao.getAccount(mobileNo);
	}

	@Override
	public int rechargeAccount(String mobileno, double rechargeAmount) {
		// TODO Auto-generated method stub
		
		return accountdao.rechargeAccount(mobileno, rechargeAmount);
	}

	@Override
	public boolean validate(String mobileNo, double rechargeAmount) throws AccountException {
		// TODO Auto-generated method stub

		boolean output=false;
	if((mobileNo+ "").matches("\\d{10}"))	{
		
		if(rechargeAmount==new Account().getRechargeAmount()) {
			output=true;
		}
	else {
		throw new AccountException(AccountExceptionMessages.ERROR3);
	}
	}else
	
	{
		throw new AccountException(AccountExceptionMessages.ERROR2);
	}
		return output;
	}

}
