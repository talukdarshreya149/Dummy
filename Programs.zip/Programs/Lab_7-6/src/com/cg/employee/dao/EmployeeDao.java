package com.cg.employee.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

import com.cg.employee.dto.Employee;
import com.cg.util.JavaUtil;

public class EmployeeDao implements IEmployeeDao {

	Connection con = null;

	public EmployeeDao() {

		con = JavaUtil.getConnect();
	}

	@Override
	public void addDetailsDao(Employee emp) throws Exception {
		int eid = 0;
		try {
			eid = getEmployeeId();
			String sql = "INSERT INTO Employee055 VALUES(?, ?, ?, ?, ?, ?)";
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setInt(1, eid);
			pstmt.setString(2, emp.getEname());
			pstmt.setString(3, emp.getDesignation());
			pstmt.setDouble(4, emp.getSalary());
			LocalDate today = LocalDate.now();
			Date sqlDate = Date.valueOf(today);

			pstmt.setDate(5, sqlDate);
			pstmt.setString(6, emp.getMedicalScheme());
			int row = pstmt.executeUpdate();

			if (row > 0) {

				System.out.println("Details added");
			} else {
				System.out.println("Details not added");

			}

		} catch (SQLException e) {

			e.printStackTrace();
		}

		
	}

	private int getEmployeeId() throws SQLException {

		int employeeId = 0;
		String sql = "SELECT employee_sequence.NEXTVAL FROM DUAL";

		PreparedStatement pstmt = con.prepareStatement(sql);
		ResultSet res = pstmt.executeQuery();
		if (res.next()) {
			try {
				employeeId = res.getInt(1);
			} catch (SQLException e) {

				e.printStackTrace();
			}
		}

		return employeeId;

	}

	@Override
	public Employee getEmployeeDetailsDao(String scheme1) {
		Employee emp= new Employee();
		String sql="SELECT * FROM Employee055 WHERE MEDICALSCHEME= ?";
		try {
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, scheme1);
			ResultSet res = pstmt.executeQuery();
			if(res.next())
			{
				emp.setEid(res.getInt(1));
				emp.setEname(res.getString(2));
				emp.setDesignation(res.getString(3));
				emp.setSalary(res.getDouble(4));
				Date sqlDate = res.getDate(5);
				LocalDate date = sqlDate.toLocalDate();
				emp.setDob(date);
				
			}
			
			}
		 catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		return emp;

	}

}
