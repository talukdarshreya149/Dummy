package com.cg.dao;

public interface ILoginDao {
public boolean login(String username, String password);
}
