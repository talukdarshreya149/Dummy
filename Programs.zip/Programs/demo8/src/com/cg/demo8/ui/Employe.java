package com.cg.demo8.ui;

public class Employe {

	private int empId;
	private String empName;
	private int empAge;
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpAge() {
		return empAge;
	}
	public void setEmpAge(int empAge) throws EmployeeException
{
	if(empAge<18)
	{
	throw  new EmployeeException("Age should be greater than 18");
	
	}else {
		this.empAge=empAge;
	}
}
	
	
	}
