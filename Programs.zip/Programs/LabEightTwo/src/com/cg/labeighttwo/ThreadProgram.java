package com.cg.labeighttwo;

public class ThreadProgram implements Runnable {
	static ThreadProgram obj1;
	static ThreadProgram obj2;
	static Thread t;
	static Thread t1;
	
	private int num=(int)(Math.random()*10);

	private int fact=1;
	int i= num;
	
	
	@Override
	public void run() {
	
		synchronized(t){
			if (Thread.holdsLock(t))
			{
				System.out.println("Number" + num);
				
			}
		}
		synchronized(t1)
		{
			if(Thread.holdsLock(t1))
			{
				while(i>0)
				{
					fact=fact*i;
					i--;
				}
				
				System.out.println("Factorial of num is "+ fact);
			}
			
}
}
}