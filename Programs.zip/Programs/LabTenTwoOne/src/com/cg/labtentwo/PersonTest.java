package com.cg.labtentwo;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class PersonTest extends Person{

	Person person=new Person();
	

		@Test
		void testGetFirstName() {
			person.setFirstName("shreya");
			assertEquals("shreya",person.getFirstName());
			
					}
		
		@Test
		void testGetLastName() {
			person.setLastName("talukdar");
			assertEquals("talukdar",person.getLastName());
		}

		@Test
		void testGetGender() {
			person.setGender("F");
			assertEquals("F",person.getGender());
		}
	}



