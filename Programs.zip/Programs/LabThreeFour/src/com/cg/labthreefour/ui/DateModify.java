package com.cg.labthreefour.ui;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class DateModify {
	public static void main(String[] args)

	{
			DateTimeFormatter formate= DateTimeFormatter.ofPattern("dd/MM/yyyy");
			DateTimeFormatter formate1= DateTimeFormatter.ofPattern("dd/MM/yyyy");
			 Scanner sc= new Scanner(System.in);
			 
			 System.out.println("Enter the Date in dd/mm/yyyy");
				String date =sc.next();
				String newdate=sc.next();
			
			LocalDate date1=LocalDate.parse(date,formate);
			LocalDate date2=LocalDate.parse(newdate,formate1);
		   Period period= date1.until(date2);
		   System.out.println("Days:" + period.getDays());
		   System.out.println("Months:" + period.getMonths());
		   System.out.println("Years:" + period.getYears());
	    sc.close();
	}

}
