package com.cg.student.dao;

import java.util.HashSet;

import com.cg.student.dto.StudentDto;
import com.cg.student.exception.MyException;

public interface IStudentDao {
	
	 
	 public StudentDto searchStudent(int studId);
	 public void deleteStudent(int dId);
public HashSet<StudentDto> viewStudentDetails();
	public int addStudentDao(StudentDto studentdto);
	

 
}
