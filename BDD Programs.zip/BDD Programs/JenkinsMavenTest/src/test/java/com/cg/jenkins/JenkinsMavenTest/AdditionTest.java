package com.cg.jenkins.JenkinsMavenTest;

import static org.junit.Assert.*;

import org.junit.Test;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AdditionTest {
	
	@Test
	 public void callme() throws Throwable {
		i_have_entered_into_the_calculator();
		i_press_add();
		the_result_should_be_on_the_screen();
	}
	
    @Given("^I have entered (\\d+) into the calculator$")
   public void i_have_entered_into_the_calculator() throws Throwable {
   
     System.out.println("Im in Given");
    }

    @When("^I press add$")
    public void i_press_add() throws Throwable {
 
    	System.out.println("Im in When");

     }

   @Then("^the result should be (\\d+) on the screen$")
   public void the_result_should_be_on_the_screen() throws Throwable {
   
	   System.out.println("Im in Then");
   
     }


}
