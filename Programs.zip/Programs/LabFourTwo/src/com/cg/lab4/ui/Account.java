package com.cg.lab4.ui;
public class Account extends Person
{
	private long accNum;
	 double balance;
	
		public long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	
	public double deposit(double balance,double b )
	{
		this.balance=balance;
		balance=balance+b;
		return balance;
	}
	public double withdraw(double balance, double b)
	{
		this.balance=balance;
		if(b<500)
		{
			System.out.println("Balance cannot be withdrawn");
		}
		else 
			{
		balance=balance-b;
			}
			return balance;
	}
	public double showBalance(double balance)
	{
		return balance;
	}
	}