package com.cg.demofour.ui;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class Main 
{
	public static void main(String[] args)
	{  
		DateTimeFormatter formate= DateTimeFormatter.ofPattern("dd/MM/yyyy");
		Scanner sc= new Scanner(System.in);
		
		System.out.println("Enter the Date in dd/mm/yyyy");
		String date =sc.next();
		
			LocalDate mydate= LocalDate.parse(date,formate);
			System.out.println("Date is " + mydate);
	sc.close();
	}
	}