package com.cg.lab6two.ui;

import java.util.Scanner;


public class MainAge {

	public static void main(String[] args) throws ValidateAgeException
	{
	Scanner sc=new Scanner(System.in);
	System.out.println("enter age");
	int age=sc.nextInt();
	ValidateAge emp=new ValidateAge();
	try {
		
	
	emp.setAge(age);
	} catch (ValidateAgeException e) {
		System.out.println(e.getMessage());
	}
	sc.close();
	}
	}
	
	
