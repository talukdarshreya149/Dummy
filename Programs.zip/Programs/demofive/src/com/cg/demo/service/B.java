package com.cg.demo.service;

import demofive.service.A;

// child or sub class
public class B extends A 
{
	int a;
 public B()
 {
	 //super()
	 System.out.println("In B constructor...");
 }
 
 public B(int a)
 {
	 super(a);
	 System.out.println("In B constructor..." + a);
 }
 
	
}
