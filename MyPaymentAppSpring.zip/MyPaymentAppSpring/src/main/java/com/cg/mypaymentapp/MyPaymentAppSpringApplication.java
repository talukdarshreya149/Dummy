package com.cg.mypaymentapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages="com.cg.mypaymentapp")
public class MyPaymentAppSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyPaymentAppSpringApplication.class, args);
	}
}
