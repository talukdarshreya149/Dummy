package com.cg.util;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class DriverUtil {

	private WebDriver driver=null;
		
	// The below code is used to initiate the driver
		public WebDriver initiateDriver(String name) {
			
			// If the browser is Firefox, then do this
	   if("Firefox".equals(name)) {
			 driver = new FirefoxDriver();
			 
			  // If browser is IE, then do this	  
	    }else if ("IE".equals(name)) { 
			 	driver = new InternetExplorerDriver();	 
		 }
	   else if("Chrome".equals(name)) {
				// Here I am setting up the path for my ChromeDriver
				 
		 System.setProperty("webdriver.chrome.driver","Drivers\\chromedriver.exe" );
				 driver=new ChromeDriver();
		  }
			return driver;
			
		}
		
		public void afterTest() {
			 
			driver.quit();
	 
		}

}
