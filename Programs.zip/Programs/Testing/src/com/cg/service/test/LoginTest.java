package com.cg.service.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.cg.service.ILoginsService;
import com.cg.service.LoginServiceImpl;

public class LoginTest {

	@Test
	public void TestForEmptyName() {
	ILoginsService service=new LoginServiceImpl()	;
	System.out.println(" Class");
	boolean out=service.login("  ","Admin");
	assertFalse(out);
	}
		
    @Before
	public void setUpForEmptyPassword() {
			ILoginsService service=new LoginServiceImpl()	;
			System.out.println("Before");
		boolean out=service.login("Admin ", " ");
		assertFalse(out);
				}

	@Test
	public void test() {
		ILoginsService service=new LoginServiceImpl()	;
		boolean out=service.login(" Admin","Admin");
		System.out.println("VALID");
		assertFalse(out);
	}
@BeforeClass 
public static void set() {
	
	System.out.println("Before class");
}


@Ignore
public void log() {
	ILoginsService service=new LoginServiceImpl()	;
	boolean out=service.login(" Admin","Admin");
	System.out.println("VALIDATE");
	assertFalse(out);
}


 @After
public  void testing() {
	 ILoginsService service=new LoginServiceImpl()	;
	 System.out.println("After");
	 boolean out=service.login(""," ");
	 assertFalse(out);
 }

}
