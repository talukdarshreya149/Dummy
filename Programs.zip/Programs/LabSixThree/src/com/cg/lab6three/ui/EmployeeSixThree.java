package com.cg.lab6three.ui;


	import com.cg.eis.exception.EmployeeException;

	public class EmployeeSixThree {
		 public int empId;
		 public String empName;
		 public double empSal;
		 public String empDesign;
		 public String inScheme;
		public int getEmpId() {
			return empId;
		}
		public void setEmpId(int empId) {
			this.empId = empId;
		}
		public String getEmpName() {
			return empName;
		}
		public void setEmpName(String empName) {
			this.empName = empName;
		}
		public double getEmpSal() {
			return empSal;
		}
		public void setEmpSal(double empSal) throws EmployeeException
		{
			if(empSal<3000)
			{
				
					throw  new EmployeeException("Salary should be greater than 3000");	
				}
		else 
		
		{
			this.empSal = empSal;
		}
		}
		
		public String getEmpDesign() {
			return empDesign;
		}
		public void setEmpDesign(String empDesign) {
			this.empDesign = empDesign;
		}
		public String getInScheme() {
			return inScheme;
		}
		public void setInScheme(String inScheme) {
			this.inScheme = inScheme;
		}
		
		public String checkScheme(String des, double empSal2) {
			// TODO Auto-generated method stub
			return null;
		}

	}


