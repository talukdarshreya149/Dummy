package com.cg.studentadmissionhash.dto;

import java.time.LocalDate;

public class StudentDto {

	
	
	private String name;
	private String phone;
	private String email;
	private int age;
	private char gender;
	private String city;
	private LocalDate appdate;
	private String status="Not Approved";
	private int id;
	private String collegename;
	
	public String getCollegename() {
		return collegename;
	}
	public void setCollegename(String collegename) {
		this.collegename = collegename;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public char getGender() {
		return gender;
	}
	public void setGender(char gender) {
		this.gender = gender;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public LocalDate getAppdate() {
		return appdate;
	}
	public void setAppdate(LocalDate appdate) {
		this.appdate = appdate;
	}
	@Override
	public String toString() {
		return "StudentDto [name=" + name + ", phone=" + phone + ", email=" + email + ", age=" + age + ", gender="
				+ gender + ", city=" + city + ", appdate=" + appdate + ", status=" + status + ", id=" + id
				+ ", collegename=" + collegename + "]";}
	
}
