package com.cg.democompare.ui;

public class B extends A{
public void getData()
	{
		System.out.println("print B....");
	}

	}


