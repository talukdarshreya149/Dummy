package com.cg.studentadmissionhash.dao;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

import com.cg.studentadmissionhash.dto.StudentDto;
import com.cg.studentadmissionhash.exception.IStudentException;
import com.cg.studentadmissionhash.exception.StudentException;


public class StudentColDaoImpl implements IStudentColDao{

	private static  HashMap<String,String > collegedetails=null;
	private static HashMap<Integer,StudentDto> student=null;
	
	
	static {
		
		student=new HashMap<>();
	    collegedetails=new HashMap<>();
			
		collegedetails.put("Delhi", "IIT-D");
		collegedetails.put("Hyderabad","IIIT-H");
		collegedetails.put("Chennai","IIT-M");
		collegedetails.put("Bangalore","IIS-B");
		collegedetails.put("Mumbai","IIT-B");
			
		}


	

	@Override
public HashMap<Integer, StudentDto> getStudentDetails() {
	// TODO Auto-generated method stub
	return student;
}

	@Override
	public Map<String, String> getCollegeDetails() {
		// TODO Auto-generated method stub
		return collegedetails;
	}

	@Override
	public int addStudentDetails(StudentDto studDto) {
		// TODO Auto-generated method stub
		student.put(studDto.getId(),studDto);
		return studDto.getId();
	}

	
	
	
	
}	