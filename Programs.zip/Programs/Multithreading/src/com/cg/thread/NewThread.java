package com.cg.thread;

public class NewThread implements Runnable{
 public static void main(String[] args) {
 //NewThread newt=new NewThread();
 Thread thread=new Thread(new NewThread());
 thread.start();
 System.out.println(Thread.currentThread().getName());
 for(int i=0;i<15;i++)
 {
	 System.out.println("Money");
 }

 }	


@Override
public void run()   //overrides the runmethod in the thread class
{
	System.out.println(Thread.currentThread().getName());
	for(int i=0;i<15;i++)
	{	try {
Thread.currentThread().sleep(1000);
	
	Thread.currentThread().getPriority();
	
	}catch(InterruptedException e) {
		e.printStackTrace();
	}
	System.out.println("Save");
	}	
	
}

}
