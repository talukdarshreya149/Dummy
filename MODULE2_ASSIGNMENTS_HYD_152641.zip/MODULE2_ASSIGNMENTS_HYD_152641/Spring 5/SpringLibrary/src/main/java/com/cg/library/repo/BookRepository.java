package com.cg.library.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.cg.library.beans.Book;

@Repository("bookrepo")
public interface BookRepository extends CrudRepository<Book,Integer>{

}
