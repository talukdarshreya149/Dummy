package com.cg.labelevenfour;

import java.util.function.BiFunction;

public class MainClass {
public static void main(String[] args) {
	BiFunction<Integer,String,String> employee=new Employee():: viewDetails;
	System.out.println(employee.apply(150,"Shreya"));
}
}
