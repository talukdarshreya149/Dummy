package com.cg.demosix.dto;

public class Project {
private int projId;
private String projName;
public Project()
{
	//auto generated constructor
}
public Project(int projId, String projName)
{
	super();
	this.projId=projId;
	this.projName=projName;
}
public int getProjId() {
	return projId;
}
public void setProjId(int projId) {
	this.projId = projId;
}
public String getProjName() {
	return projName;
}
public void setProjName(String projName) {
	this.projName = projName;
}

}
