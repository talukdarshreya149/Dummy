package com.cg.lambdademo;
@FunctionalInterface
public interface IDemoLambda {
 //
	public void add(int num1,int num2);

}
