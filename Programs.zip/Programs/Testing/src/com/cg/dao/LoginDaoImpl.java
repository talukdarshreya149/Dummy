package com.cg.dao;

public class LoginDaoImpl implements ILoginDao{

	@Override
	public boolean login(String username, String password) {
		// TODO Auto-generated method stub
		boolean output=false;
		if(username.equalsIgnoreCase("Admin")&&password.equalsIgnoreCase("Admin")){
			output=true;
		}
		
		return output;
	}

}
