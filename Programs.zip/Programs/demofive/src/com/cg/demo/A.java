package com.cg.demo;
// parent class
public class A 
{
	int eid=10;
	public void getData() {
		System.out.println("the value of eid is");
	}

}
