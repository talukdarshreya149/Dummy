package com.cg.student.exception;

public interface IMyExceptionMessages {
String ERROR1="Invalid error. Try Again";
String ERROR2="Invalid Name. Try Again";
String ERROR="Invalid DOB.Try Again ";

}
