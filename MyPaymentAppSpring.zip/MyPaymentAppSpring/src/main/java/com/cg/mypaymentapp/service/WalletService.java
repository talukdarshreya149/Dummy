package com.cg.mypaymentapp.service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import com.cg.mypaymentapp.bean.Customer;

public interface WalletService {
	public void createAccount(Customer customer);
	public Optional<Customer> showBalance(String mobileno);
	public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, BigDecimal amount) ;
	public Customer depositAmount (String mobileNo,BigDecimal amount );
	public Customer withdrawAmount(String mobileNo, BigDecimal amount);
	public String printTransaction(String mobile);	
}
