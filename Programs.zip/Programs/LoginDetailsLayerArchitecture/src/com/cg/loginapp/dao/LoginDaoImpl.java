package com.cg.loginapp.dao;

import java.util.HashMap;

import com.cg.loginapp.dto.UserBean;
import com.cg.loginapp.exception.IMyLoginExceptionMessages;
import com.cg.loginapp.exception.MyLoginException;
import com.cg.loginapp.staticdb.LoginDataBase;

public class LoginDaoImpl implements ILoginDao {

	@Override
	public String getLoginPassword(UserBean userBean) throws MyLoginException {
		String dbPassword = "-1";
		try {
			
		
		HashMap<String, String> db=LoginDataBase.getLoginDetails();
	dbPassword=	db.get(userBean.getUserName());
		}catch(Exception exception) {
			throw new MyLoginException(IMyLoginExceptionMessages.ERROR1);
			
		}
		return dbPassword;
	

}
}